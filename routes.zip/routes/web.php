<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('admin.dashboard');
// });

Auth::routes();

Route::group(['middleware' => ['auth']], function () {

    Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
    Route::group(['prefix' => 'admin'], function () {
        Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

        Route::group(['prefix' => 'department'], function () {
            Route::get('/', [App\Http\Controllers\DepartmentController::class, 'index'])->name('departments_home');
            Route::get('/edit_department', [App\Http\Controllers\DepartmentController::class, 'edit_department'])->name('edit_department');
            Route::post('/store', [App\Http\Controllers\DepartmentController::class, 'store'])->name('store_department');
            Route::post('/update/{id}', [App\Http\Controllers\DepartmentController::class, 'update'])->name('update_department');
            Route::get('/destroy', [App\Http\Controllers\DepartmentController::class, 'delete'])->name('delete_department');
        });

        Route::group(['prefix' => 'tax'], function () {
            Route::get('/', [App\Http\Controllers\TaxController::class, 'index'])->name('taxes_home');
            Route::post('/store', [App\Http\Controllers\TaxController::class, 'StoreTax'])->name('add_new_tax');
            Route::get('/edit_department', [App\Http\Controllers\TaxController::class, 'TaxDeduction'])->name('tax_deduction_home');
            Route::post('/update', [App\Http\Controllers\TaxController::class, 'UpdateTax'])->name('update_tax');
            Route::get('/destroy', [App\Http\Controllers\TaxController::class, 'delete'])->name('delete_tax');
            Route::get('/gettaxInfos', [App\Http\Controllers\TaxController::class, 'gettaxInfo'])->name('gettaxInfos');
        });

        Route::group(['prefix' => 'approval_level'], function () {
            Route::get('/', [App\Http\Controllers\ApprovallevelController::class, 'index'])->name('approval_level_home');
            Route::post('/create_app', [App\Http\Controllers\ApprovallevelController::class, 'create'])->name('create_approval_level');
            Route::get('/delete', [App\Http\Controllers\ApprovallevelController::class, 'delete'])->name('delete_approval_level');
            Route::get('/edit/{id}', [App\Http\Controllers\ApprovallevelController::class, 'viewdetails'])->name('edit_approval_level');
            Route::get('/list/{role}', [App\Http\Controllers\ApprovallevelController::class, 'veiw_role_list'])->name('veiw_approval_level_role_list');
            Route::post('/update', [App\Http\Controllers\ApprovallevelController::class, 'update'])->name('update_approval_level');
        });

        //beneficiaries
        Route::group(['prefix' => 'beneficiary'], function () {
            Route::get('/', [App\Http\Controllers\BeneficiaryController::class, 'index'])->name('beneficiaries_list');
            Route::get('/add', [App\Http\Controllers\BeneficiaryController::class, 'add_beneficiary'])->name('add_beneficiary');
            Route::get('/get_account_list', [App\Http\Controllers\BeneficiaryController::class, 'getBeneficiaryAccount'])->name('get_beneficiary_account');
            Route::get('/edit/{id}', [App\Http\Controllers\BeneficiaryController::class, 'edit_beneficiary'])->name('edit_beneficiary');
            Route::post('/update', [App\Http\Controllers\BeneficiaryController::class, 'update_beneficiary'])->name('update_beneficiary');
            Route::post('/create', [App\Http\Controllers\BeneficiaryController::class, 'create_beneficiary'])->name('create_beneficiary');
        });
        
        Route::group(['prefix' => 'users'], function () {
            Route::get('/', [App\Http\Controllers\UserController::class, 'index'])->name('admin_users');
            Route::post('/store', [App\Http\Controllers\UserController::class, 'store'])->name('add_new_admin_user');
            Route::get('/getuser_detail', [App\Http\Controllers\UserController::class, 'getUserInfor'])->name('getUserInfos');
            Route::any('/update', [App\Http\Controllers\UserController::class, 'update_user'])->name('update_admin_users');
            Route::get('/fetch', [App\Http\Controllers\UserController::class, 'fetch_users'])->name('fetch_user');
            Route::get('/delete', [App\Http\Controllers\UserController::class, 'destroy'])->name('delete_user');
        });

        Route::group(['prefix' => 'role'], function () {
            Route::get('/', [App\Http\Controllers\RoleController::class, 'index'])->name('roles_home');
            Route::get('/create', [App\Http\Controllers\RoleController::class, 'create'])->name('create_role');
            Route::post('/store', [App\Http\Controllers\RoleController::class, 'store'])->name('store_role');
            Route::post('/update/{id}', [App\Http\Controllers\RoleController::class, 'update'])->name('update_role');
            Route::any('/show/{id}', [App\Http\Controllers\RoleController::class, 'show'])->name('show_role');
            Route::get('/edit/{id}', [App\Http\Controllers\RoleController::class, 'edit'])->name('edit_role');
            Route::get('/destroy', [App\Http\Controllers\RoleController::class, 'destroy'])->name('destroy_role');
        });

        Route::group(['prefix' => 'department'], function () {
            Route::get('/', [App\Http\Controllers\DepartmentController::class, 'index'])->name('departments_home');
            Route::get('/edit_department', [App\Http\Controllers\DepartmentController::class, 'edit_department'])->name('edit_department');
            Route::post('/store', [App\Http\Controllers\DepartmentController::class, 'store'])->name('store_department');
            Route::post('/update/{id}', [App\Http\Controllers\DepartmentController::class, 'update'])->name('update_department');
            Route::get('/destroy', [App\Http\Controllers\DepartmentController::class, 'delete'])->name('delete_department');
        });

        Route::group(['prefix' => 'approval_level'], function () {
            Route::get('/', [App\Http\Controllers\ApprovallevelController::class, 'index'])->name('approval_level_home');
            Route::post('/create_app', [App\Http\Controllers\ApprovallevelController::class, 'create'])->name('create_approval_level');
            Route::get('/delete', [App\Http\Controllers\ApprovallevelController::class, 'delete'])->name('delete_approval_level');
            Route::get('/edit/{id}', [App\Http\Controllers\ApprovallevelController::class, 'viewdetails'])->name('edit_approval_level');
            Route::get('/list/{role}', [App\Http\Controllers\ApprovallevelController::class, 'veiw_role_list'])->name('veiw_approval_level_role_list');

            Route::post('/update', [App\Http\Controllers\ApprovallevelController::class, 'update'])->name('update_approval_level');
        });
        //beneficiaries
        Route::group(['prefix' => 'beneficiary'], function () {
            Route::get('/', [App\Http\Controllers\BeneficiaryController::class, 'index'])->name('beneficiaries_list');
            Route::get('/add', [App\Http\Controllers\BeneficiaryController::class, 'add_beneficiary'])->name('add_beneficiary');
            Route::get('/get_account_list', [App\Http\Controllers\BeneficiaryController::class, 'getBeneficiaryAccount'])->name('get_beneficiary_account');
            Route::get('/edit/{id}', [App\Http\Controllers\BeneficiaryController::class, 'edit_beneficiary'])->name('edit_beneficiary');
            Route::post('/update', [App\Http\Controllers\BeneficiaryController::class, 'update_beneficiary'])->name('update_beneficiary');
            Route::post('/create', [App\Http\Controllers\BeneficiaryController::class, 'create_beneficiary'])->name('create_beneficiary');
        });

        Route::group(['prefix' => 'payment'], function () {
            Route::group(['prefix' => 'voucher'], function () {
                Route::get('/', [App\Http\Controllers\PaymentController::class, 'vouchers'])->name('payment_vouchers');
                Route::get('/prepare_voucher', [App\Http\Controllers\PaymentController::class, 'prepare_voucher'])->name('prepare_new_voucher');
                Route::get('/edit_voucher/{id}', [App\Http\Controllers\PaymentController::class, 'edit_voucher'])->name('edit_payment_voucher');
                Route::get('/print_voucher/{id}', [App\Http\Controllers\PaymentController::class, 'print_voucher'])->name('print_voucher_payment_voucher');
                Route::post('/save_voucher', [App\Http\Controllers\PaymentController::class, 'save_voucher'])->name('save_voucher');
                Route::post('/update_voucher/{id}', [App\Http\Controllers\PaymentController::class, 'update_voucher'])->name('update_voucher');
            });
        });



        Route::group(['prefix' => 'asset'], function () {
            Route::get('/asset_home', [App\Http\Controllers\AssetController::class, 'asset_index'])->name('assets_index');
            Route::get('/create_asset', [App\Http\Controllers\AssetController::class, 'create_asset'])->name('asset_registration');
            Route::post('/store_asset', [App\Http\Controllers\AssetController::class, 'store_asset'])->name('store_this_assets');
            Route::post('/update_asset', [App\Http\Controllers\AssetController::class, 'update_asset'])->name('update_assets');
            Route::any('/show_asset/{id}', [App\Http\Controllers\AssetController::class, 'show_asset'])->name('show_assets');
            Route::get('/download_excel/{type}', [App\Http\Controllers\AssetController::class, 'download_asset_excel'])->name('download_assets_excel');
            Route::post('/upload_excel', [App\Http\Controllers\AssetController::class, 'upload_asset_excel'])->name('upload_assets_excel');
            Route::get('/edit_asset/{id}', [App\Http\Controllers\AssetController::class, 'edit_asset'])->name('edit_assets');
            Route::get('/destroy_asset/{id}', [App\Http\Controllers\AssetController::class, 'delete_asset'])->name('delete_assets');


            Route::group(['prefix' => 'disposal'], function () {
                Route::get('/', [App\Http\Controllers\AssetController::class, 'disposal_index'])->name('disposals_index');
                Route::post('/create_disposal', [App\Http\Controllers\AssetController::class, 'create_disposal'])->name('create_disposals');
                Route::post('/store_disposal', [App\Http\Controllers\AssetController::class, 'store_disposal'])->name('store_disposals');
                Route::get('/getsupplier_detail', [App\Http\Controllers\AssetController::class, 'getAssetInfo'])->name('getAssetInfo');
                Route::post('/update_disposal}', [App\Http\Controllers\AssetController::class, 'update_disposal'])->name('update_disposals');
                Route::any('/show_disposal/{id}', [App\Http\Controllers\AssetController::class, 'show_disposal'])->name('show_disposals');
                Route::get('/edit_disposal/{id}', [App\Http\Controllers\AssetController::class, 'edit_disposal'])->name('edit_disposals');
                Route::get('/destroy_disposal/{id}', [App\Http\Controllers\AssetController::class, 'delete'])->name('delete_disposals');
            });
        });


        Route::group(['prefix' => 'classification'], function () {
            Route::get('/', [App\Http\Controllers\AssetController::class, 'classification_index'])->name('classifications_index');
            Route::get('/create_classification', [App\Http\Controllers\AssetController::class, 'create_classification'])->name('create_classifications');
            Route::post('/store_classification', [App\Http\Controllers\AssetController::class, 'store_classification'])->name('store_classifications');
            Route::get('/getclassification_detail', [App\Http\Controllers\AssetController::class, 'getAssetInform'])->name('getAssetInfors');
            Route::post('/update_classification', [App\Http\Controllers\AssetController::class, 'update_classification'])->name('update_classifications');
            Route::any('/show_classification/{id}', [App\Http\Controllers\AssetController::class, 'show_classification'])->name('show_classifications');
            Route::get('/edit_classification/{id}', [App\Http\Controllers\AssetController::class, 'edit_classification'])->name('edit_classifications');
            Route::get('/destroy_classification/{id}', [App\Http\Controllers\AssetController::class, 'delete_classification'])->name('delete_classifications');
        });


        Route::group(['prefix' => 'supplier'], function () {
            Route::get('/', [App\Http\Controllers\AssetController::class, 'supplier_index'])->name('suppliers_index');
            Route::post('/create_supplier', [App\Http\Controllers\AssetController::class, 'create_supplier'])->name('create_suppliers');
            Route::post('/update_supplier', [App\Http\Controllers\AssetController::class, 'update_supplier'])->name('update_suppliers');
            Route::any('/show_supplier/{id}', [App\Http\Controllers\AssetController::class, 'show_supplier'])->name('show_suppliers');
            Route::get('/edit_supplier/{id}', [App\Http\Controllers\AssetController::class, 'edit_supplier'])->name('edit_suppliers');
            Route::get('/destroy_supplier/{id}', [App\Http\Controllers\AssetController::class, 'delete_supplier'])->name('delete_suppliers');
        });


        Route::group(['prefix' => 'journals'], function () {
            Route::get('/', [App\Http\Controllers\journalController::class, 'index'])->name('journal.home');
            Route::get('/income', [App\Http\Controllers\journalController::class, 'income'])->name('income');
            Route::post('/create/account', [App\Http\Controllers\journalController::class, 'save'])->name('save.journal');
            Route::any('/lodge', [App\Http\Controllers\journalController::class, 'lodge'])->name('journal.lodge');
            Route::post('/bank', [App\Http\Controllers\journalController::class, 'bankLodge'])->name('lodge.bank');
        });

        Route::group(['prefix' => 'category'], function () {
            Route::any('/', [App\Http\Controllers\CategoryController::class, 'index'])->name('category.home');
            Route::post('/create', [App\Http\Controllers\CategoryController::class, 'create'])->name('save.category');
            Route::post('/create_sub_category', [App\Http\Controllers\CategoryController::class, 'addSubCategory'])->name('create.sub.category');
            Route::get('/edit', [App\Http\Controllers\CategoryController::class, 'getCategoryId'])->name('get_category_by_id');
            Route::get('/{id}', [App\Http\Controllers\CategoryController::class, 'details'])->name('category.details');
            Route::get('/deleteCategory', [App\Http\Controllers\RoleController::class, 'deleteCategory'])->name('category_delete');
            // Route::get('/getSubCategory', [App\Http\Controllers\CategoryController::class, 'getSubCategory'])->name('get_sub_category');

        });



        Route::group(['prefix' => 'payment'], function () {
            Route::get('/', [App\Http\Controllers\PaymentController::class, 'index'])->name('payment_home');
        });

        Route::group(['prefix' => 'reports'], function () {
            Route::get('/charts-of-account', [App\Http\Controllers\ReportController::class, 'chartOfAccount'])->name('charts_of_account');
            Route::get('/general-ledger', [App\Http\Controllers\ReportController::class, 'generalLedger'])->name('general_ledger');
            Route::get('/cashbook', [App\Http\Controllers\ReportController::class, 'cashbook'])->name('cashbook');
            Route::get('/trial-balance', [App\Http\Controllers\ReportController::class, 'trialBalance'])->name('trial_balance');
            Route::get('/balance-sheet', [App\Http\Controllers\ReportController::class, 'balanceSheet'])->name('balance_sheet');
            Route::get('/searchLedger', [App\Http\Controllers\ReportController::class, 'searchLedger'])->name('searchAndFilter_cashbook');
            Route::get('/searchJournal', [App\Http\Controllers\ReportController::class, 'searchJournal'])->name('searchAndFilter_journal');
            Route::get('/searchReceipt', [App\Http\Controllers\ReportController::class, 'searchReceipt'])->name('searchAndFilterReceipts');
        });

        Route::group(['prefix' => 'accounts'], function () {
            Route::get('/', [App\Http\Controllers\AccountController::class, 'index'])->name('account.home');
            Route::get('/edit', [App\Http\Controllers\AccountController::class, 'edit'])->name('account.edit');
            Route::get('/delete', [App\Http\Controllers\AccountController::class, 'delete'])->name('account.delete');
            Route::post('/create', [App\Http\Controllers\AccountController::class, 'save'])->name('account.save');
            Route::post('/update', [App\Http\Controllers\AccountController::class, 'update'])->name('account.update');
            Route::post('/create/account', [App\Http\Controllers\AccountController::class, 'saveAccount'])->name('account.save.ledger');
            Route::get('/allocate', [App\Http\Controllers\AccountController::class, 'allocateIndex'])->name('manage.account.home');
            Route::get('/get_gl_code', [App\Http\Controllers\AccountController::class, 'getCode'])->name('get_gl_code');
            Route::get('/search', [App\Http\Controllers\AccountController::class, 'search'])->name('search.journal');
            Route::get('/import', [App\Http\Controllers\AccountController::class, 'import'])->name('import.account');
            Route::post('/import/data', [App\Http\Controllers\AccountController::class, 'importData'])->name('import.data');
            Route::any('/searchData', [App\Http\Controllers\AccountController::class, 'searchData'])->name('search.data');
            Route::get('/getSubCategory', [App\Http\Controllers\AccountController::class, 'getSubCategory'])->name('get_sub_category');
            Route::get('/getSubCategorys', [App\Http\Controllers\AccountController::class, 'getSubCategorys'])->name('get_sub_categorys');
            
            Route::group(['prefix' => 'lodge'], function () {
                Route::any('/', [App\Http\Controllers\AccountController::class, 'lodge'])->name('lodge.home');
                Route::get('/journal', [App\Http\Controllers\AccountController::class, 'lodgeJournal'])->name('lodgement.journal');
                Route::get('/bank.lodge', [App\Http\Controllers\AccountController::class, 'lodgeBankk'])->name('lodge.bank.home');
                Route::get('/receipt/{id}', [App\Http\Controllers\AccountController::class, 'receipt'])->name('print.receipt');
                Route::post('/bank', [App\Http\Controllers\AccountController::class, 'bankLodge'])->name('lodge.bank1');
            });
        });



        Route::group(['prefix' => 'customer'], function () {
            Route::get('/', [App\Http\Controllers\CustomersController::class, 'index'])->name('customer_home');
            Route::post('/create', [App\Http\Controllers\CustomersController::class, 'create'])->name('create_new_customer');
            Route::get('/user_id', [App\Http\Controllers\CustomersController::class, 'edit'])->name('get_customer_by_id');
            Route::get('/delete', [App\Http\Controllers\CustomersController::class, 'delete'])->name('delete_customer');
            Route::get('/customer_ledger', [App\Http\Controllers\CustomersController::class, 'customerLedger'])->name('customer_ledger');
            Route::get('/creditor_ledger', [App\Http\Controllers\CustomersController::class, 'creditorsLedger'])->name('creditors_ledger');
            Route::get('/customer_ledger/details/{id}', [App\Http\Controllers\CustomersController::class, 'customerLedgerDetails'])->name('customer_ledger_details');
            Route::get('/make_payment/{id}', [App\Http\Controllers\CustomersController::class, 'ledgerPayment'])->name('customer_ledger_payment');
            Route::post('/update', [App\Http\Controllers\CustomersController::class, 'update'])->name('update_customer');
        });

        Route::group(['prefix' => 'location'], function () {
            Route::get('/', [App\Http\Controllers\LocationController::class, 'index'])->name('location_home');
            Route::post('/create', [App\Http\Controllers\LocationController::class, 'create'])->name('create_new_location');
            Route::get('/delete', [App\Http\Controllers\LocationController::class, 'delete'])->name('delete_location');
            Route::get('/location_id', [App\Http\Controllers\LocationController::class, 'edit'])->name('get_location_by_id');
            Route::post('/update', [App\Http\Controllers\LocationController::class, 'update'])->name('update_location');
            Route::post('/createDelivery', [App\Http\Controllers\LocationController::class, 'stockDelivery'])->name('create_stock_delivery');
        });

        Route::group(['prefix' => 'secondstock'], function () {
            Route::get('/', [App\Http\Controllers\SecondStockController::class, 'index'])->name('SecondStock.home');
            Route::get('/stock_price', [App\Http\Controllers\SecondStockController::class, 'stockPrice'])->name('get_second_stock_price');
            Route::post('/create', [App\Http\Controllers\SecondStockController::class, 'create'])->name('create_new_SecondStock');
            Route::get('/delete', [App\Http\Controllers\SecondStockController::class, 'delete'])->name('delete_SecondStock');
            Route::get('/SecondStock_id', [App\Http\Controllers\SecondStockController::class, 'edit'])->name('get_SecondStock_by_id');
            Route::post('/update', [App\Http\Controllers\SecondStockController::class, 'update'])->name('update_SecondStock');
            Route::get('/individual', [App\Http\Controllers\SecondStockController::class, 'individual'])->name('abk_individual_sales_home');
            Route::post('/individual/create', [App\Http\Controllers\SecondStockController::class, 'individualSales'])->name('create_abk_individual_sales');
            Route::post('/customer/create', [App\Http\Controllers\SecondStockController::class, 'customerDiscountSales'])->name('create_customer_sales');
            Route::get('/customer', [App\Http\Controllers\SecondStockController::class, 'customer'])->name('abk_customer_sales_home');
        });


        Route::group(['prefix' => 'stock_category'], function () {
            Route::get('/', [App\Http\Controllers\StockCategoryController::class, 'index'])->name('stock_category_home');
            Route::post('/create', [App\Http\Controllers\StockCategoryController::class, 'create'])->name('create_new_stock_category');
            Route::get('/delete', [App\Http\Controllers\StockCategoryController::class, 'delete'])->name('delete_stock_category');
            Route::get('/stock_category_id', [App\Http\Controllers\StockCategoryController::class, 'edit'])->name('get_stock_category_by_id');
            Route::post('/update', [App\Http\Controllers\StockCategoryController::class, 'update'])->name('update_stock_category');
        });

        Route::group(['prefix' => 'stock'], function () {
            Route::get('/', [App\Http\Controllers\StockController::class, 'index'])->name('stock_home');
            Route::post('/create', [App\Http\Controllers\StockController::class, 'create'])->name('create_new_stock');
            Route::get('/stock_price', [App\Http\Controllers\StockController::class, 'stockPrice'])->name('get_stock_price');
            Route::get('/stock_id', [App\Http\Controllers\StockController::class, 'edit'])->name('get_stock_by_id');
            Route::get('/stock_delivery', [App\Http\Controllers\StockController::class, 'stockDelivery'])->name('stock_delivery');
            Route::post('/update', [App\Http\Controllers\StockController::class, 'update'])->name('update_stock');
            Route::get('/delete', [App\Http\Controllers\StockController::class, 'delete'])->name('delete_stock');
        });

        Route::group(['prefix' => 'sales'], function () {
            Route::get('/', [App\Http\Controllers\SaleController::class, 'index'])->name('sales_home');
            Route::get('/creditor', [App\Http\Controllers\SaleController::class, 'creditorSale'])->name('creditors_sales');
            Route::get('/dailyCreditorsSales', [App\Http\Controllers\SaleController::class, 'dailyCreditorSale'])->name('daily_creditors_sales');
            Route::post('/creditor/create', [App\Http\Controllers\SaleController::class, 'createCreditorSale'])->name('create_new_creditor_sales');
            Route::get('/sales/representative/home', [App\Http\Controllers\SaleController::class, 'dailySalesRepresentativeHome'])->name('daily_sales_representative_home');
            Route::get('/sales/representative/daily', [App\Http\Controllers\SaleController::class, 'dailySalesRepresentative'])->name('daily_sales_representative_sales');
            Route::get('/individual', [App\Http\Controllers\SaleController::class, 'individual'])->name('individual_sales_home');
            Route::post('/create', [App\Http\Controllers\SaleController::class, 'sales'])->name('create_new_sales');
            Route::post('/individual/invoice', [App\Http\Controllers\SaleController::class, 'individualSales'])->name('create_new_individual_sales');
            Route::get('/individual/daily', [App\Http\Controllers\SaleController::class, 'dailySales'])->name('daily_sales_home');
            Route::get('/customer/daily', [App\Http\Controllers\SaleController::class, 'dailyCustomerSales'])->name('daily_Customer_sales');
            Route::get('/individual/daily/salesdetails/{id}', [App\Http\Controllers\SaleController::class, 'dailyIndividualSalesDetails'])->name('individual_daily_details');
            Route::get('/individual/daily/invoice/reprint/{id}', [App\Http\Controllers\SaleController::class, 'reprintReceipt'])->name('individual_daily_details_print');

            Route::group(['prefix' => 'invoices'], function () {
                Route::get('/', [App\Http\Controllers\SaleController::class, 'invoices'])->name('invoice_home');
                Route::get('/pending_invoice', [App\Http\Controllers\SaleController::class, 'pendingInvoice'])->name('pending_invoices');
                Route::get('/paid_invoice', [App\Http\Controllers\SaleController::class, 'paidInvoice'])->name('paid_invoices');
                Route::get('/make_payment/{id}', [App\Http\Controllers\SaleController::class, 'makePayment'])->name('make_invoice_payment');
                Route::get('/invoice_details/{id}', [App\Http\Controllers\SaleController::class, 'invoiceDetail'])->name('invoice_details_home');
                Route::post('/pay', [App\Http\Controllers\SaleController::class, 'payment'])->name('make_invoice_payment_now');
                Route::get('/invoice_items', [App\Http\Controllers\SaleController::class, 'invoiceItems'])->name('get_invoice_items');
                Route::get('/search_invoice_home', [App\Http\Controllers\SaleController::class, 'searchAndFilter'])->name('search_invoice_home');
                Route::get('/payment_home', [App\Http\Controllers\SaleController::class, 'paymentHome'])->name('payments_home');
            });
        });
    });
    Route::get('/logout', [App\Http\Controllers\Auth\LoginController::class, 'logout'])->name('logout');
});
