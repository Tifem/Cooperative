<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SecondStock extends Model
{
    protected $table = "second_stocks";

    protected $fillable = [
        'name',
        'description',
        'unit_price',
        're_order_level',
        'quantity',
        'unit_of_measurement',
        'unit_discount',

       
    ];
}
