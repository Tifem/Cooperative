<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SalesDetails extends Model
{
    protected $table = 'sales';

    protected $fillable = [
        'order_id',
        'status',
        'amount',
        'customer_id',
        'name',
        'is_credit',
        'sales_by',
    ];

    public function customer()
    {
        return $this->belongsTo('App\Customers','customer_id')->withDefault(['name'=>'Anonymous']);
    }
    
    public function stock()
    {
        return $this->belongsTo('App\Stock','item')->withDefault(['name'=>'Anonymous']);
    }
}
