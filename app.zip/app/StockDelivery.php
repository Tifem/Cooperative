<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StockDelivery extends Model
{
    protected $table = 'stock_deliveries';

    protected $fillable =[
        'purchase_order	',
        'supplier',
        'total_amount',
        'quantity',
        'item',
    ];
}
