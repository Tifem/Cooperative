<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StockCategory extends Model
{
    protected $table = "stockcategories";

    protected $fillable = [
        'category_name'
    ];
}
