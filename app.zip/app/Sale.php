<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sale extends Model
{
    protected $table = 'saledeliveries';

    protected $fillable = [
        'order_id',
        'item',
        'unit',
        'discount',
        'amount',
        'sales_by',
        'customer_id'
    ];

    public function stock()
    {
        return $this->belongsTo('App\Stock','item')->withDefault(['description'=>'Anonymous']);
    }

    public function customer()
    {
        return $this->belongsTo('App\Customers','customer_id')->withDefault(['name'=>'Anonymous']);
    }
};
