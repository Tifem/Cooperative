<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    protected $table = 'payments';

    protected $fillable = [
        'order_id',
        'amount_to_pay',
        'amount_paid',
        'balance',
        'customer_id',
        'user_id',
    ];
}
