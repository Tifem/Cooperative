<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SalesDelivery extends Model
{
    protected $table = 'saledeliveries';

    protected $fillable = [
        'order_id',
        'item',
        'unit',
        'discount',
        'amount',
        'sales_by',
    ];

    public function stock()
    {
        return $this->belongsTo('App\Stock','item')->withDefault(['name'=>'Anonymous']);
    }
}
