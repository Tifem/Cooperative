<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithColumnWidths;


class AssetExport implements FromCollection, WithHeadings,WithColumnWidths
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return $collection = collect([]);
    }

    public function headings() : array{
        return [
            'S/N',
            'Asset Name',
            'Serial No',
            'Purchase Date',
            'Amount Purchased',
            'Supplier',
        ];
    }

    public function columnWidths(): array
    {
        return [
            'A' => 10,
            'B' => 45,
            'C' => 55,
            'D' => 45,
            'E' => 55,
            'F' => 45,
        ];
    }
}
