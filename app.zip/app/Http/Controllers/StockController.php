<?php

namespace App\Http\Controllers;
use function App\Helpers\api_request_response;
use function App\Helpers\generate_random_password;
use function App\Helpers\generate_uuid;
use function App\Helpers\unauthorized_status_code;
use function App\Helpers\bad_response_status_code;
use function App\Helpers\success_status_code;

use App\Stock;
use App\Customers;
use App\StockCategory;
use App\StockDelivery;
use App\Stock_received;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class StockController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $stocks = Stock::all();
        $data["stocks"] = $stocks;
        $stockCategories = StockCategory::all();
        $data["stockCategories"] = $stockCategories;
        return view ('stocks.stock', $data)->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create1(Request $request)
    {
        $input = $request->all();
   //dd($input);
        try{

             $stock = Stock::create($input);

             $success['stock'] = $stock;

             return redirect()->back();
        }

         catch (\Exception $exception) {
        // DB::rollback();

        return redirect()->back();

      }
    }

    public function create(Request $request)
    {
        $input = $request->all();

        try{

             $stock = Stock::create($input);

             $success['stock'] = $stock;

             return api_request_response(
                 "ok",
                 "Data Update successful!",
                 success_status_code(),
                 $stock
             );
        }

         catch (\Exception $exception) {
        // DB::rollback();

         return api_request_response(
             "error",
             $exception->getMessage(),
             bad_response_status_code()
         );

      }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function stockPrice(Request $request)
    {
          //  dd($request->all());
          $stock  =  Stock::where('id',   $request->id)->first();

          return response()->json($stock);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Stock  $stock
     * @return \Illuminate\Http\Response
     */
    public function delete(Request $request)
    {
        $id=$request->id;


        $stock = Stock::find($id);
        $stock->delete();

        return redirect()->back()->with('deleted', 'Delete Success!');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Stock  $stock
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
         //  dd($request->all());
         $stock =  Stock::where('id',   $request->id)->first();//Beneficiaries::all();
        //  $price['data'] = $stock -> unit_price;
        //  dd($stock);
         return response()->json($stock);
    }

    public function update(Request $request)
    {

        // dd("here");
         try{
                $input = $request->all();
               $id =$request->id;

              $stock = Stock::where('id',$id)->firstOrFail();

              $stock=  $stock->update($input);

               return api_request_response(
                   "ok",
                   "Data Update successful!",
                   success_status_code(),
                   $stock
               );
         }
           catch (\Exception $exception) {
           return api_request_response(
               "error",
               $exception->getMessage(),
               bad_response_status_code()
           );

       }


    }

    public function stockDelivery()
    {
        $stocks = Stock::all();
        $data["stocks"] = $stocks;

        $customers = Customers::all();
        $data["customers"] = $customers;
        return view ('stocks.stock_delivery1', $data);
    }

    public function addStockDelivery(Request $request)
    {

        $input = $request->all();

        try{
            $input = $request->all();
            $item = $input['item'];
            // dd($input);
            $user_id = Auth::user()->id;
            // dd($salesBy);
            $supplier_id = $input['customer_id'];
            $data['order_id'] = $order_id= $input['order_id'] = rand();
            $amount = 2000;
            foreach($item as $key => $item)
                {
                    $stock_item = new StockDelivery;
                    $stock_item->total_amount = $amount;
                    $stock_item->item = $input['item'][$key];
                    $stock_item->quantity = $input['quantity'][$key];
                    // dd($stock_item);
                    $stock_item->purchase_order = $order_id;
                    $stock_item->supplier = $supplier_id;
                    $stock_item->save();
                    // dd($stock_item);
                    $stock = Stock::where('id',  $stock_item->item)->first();
                    $stock_quantity = $stock->quantity + $stock_item->unit;
                    $stock->update(['quantity' => $stock_quantity]);
                }

                $data['details'] = $details = new Stock_received;
                $details->total_quantity = $input['all_sum'];
                $details->purchase_order = $order_id;
                $details->user_id = Auth::user()->id;
                $details->supplier_id = $supplier_id;
                $details->save();

                return api_request_response(
                    "ok",
                    "Data Update successful!",
                    success_status_code(),
                    $details
                );

        }

        catch (\Exception $exception) {

            return redirect()->back()->withErrors(['exception' => $exception->getMessage()]);

        }
    }
}
