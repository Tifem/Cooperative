<?php

namespace App\Http\Controllers;
use function App\Helpers\api_request_response;
use function App\Helpers\generate_random_password;
use function App\Helpers\generate_uuid;
use function App\Helpers\unauthorized_status_code;
use function App\Helpers\bad_response_status_code;
use function App\Helpers\success_status_code;

use App\Sale;
use App\Models\User;
use App\Customers;
use App\Stock;
use App\Payment;
use App\SalesDetails;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;




class SaleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $last=Auth::user()->last_name;
        $first=Auth::user()->first_name;
        $name= $first.' '.$last ;
        $data['user_name'] = $name;
        // dd($data);
        $stocks = Stock::all();
        $data["stocks"] = $stocks;

        $customers = Customers::all();
        $data["customers"] = $customers;
        return view ('sales.sales3', $data);
    }

    public function dailySalesRepresentativeHome()
    {
       
        $data["users"] = $users = User::where('role_id', 5)->get();
        // dd($users);
        return view ('sales.sales_representative_home', $data);
    }

    public function reprintReceipt(Request $request)
    {
        $data['order_id'] = $id = $request->id;
        $data['details'] = $details = SalesDetails::where('order_id', $id)->first();
        $data['total_amount'] = $details->amount;
        $data['buyer'] = $details->customer_id;
        $data['sales'] = $sales = Sale::where('order_id', $id)->get();
            // dd($users);
            return view ('individual_invoice', $data);
    }

    public function dailySalesRepresentative(Request $request)
    {       
        $mda=$request->get('mda');
        //   dd($mda);
        $start = Carbon::parse($request->start)->startOfDay(); 
        $end = Carbon::parse($request->end)->endOfDay();
             try {
                  $sales= DB::table('saledeliveries')->whereBetween('created_at', [$start, $end])->where('sales_by', $mda)->get();
    // dd($sales);
                  if(!count($sales))
                  {

                    $sales = collect([
                      (object) [
                        
                          "created_at" => "NIL",
                          "order_id" => "NIL",
                          "name" => "NIL",
                          "amount" => "NIL",  
                          "status" => "NIL",  
                      ],
                     
                    ]);
                  }
     
                                  
                 return api_request_response(
                       "ok",
                       "Data fetching successful!",
                       success_status_code(),
                       $sales
                   );
             } catch(\Exception $exception) {
                 return api_request_response(
                   "error",
                   $exception->getMessage(),
                   bad_response_status_code()
               );
             }
    }

    public function individual()
    {
        $last=Auth::user()->last_name;
        $first=Auth::user()->first_name;
        $name= $first.' '.$last ;
        $data['user_name'] = $name;
        // dd($data);
        $stocks = Stock::all();
        $data["stocks"] = $stocks;

        $customers = Customers::all();
        $data["customers"] = $customers;
        return view ('sales.individual', $data);
    }

    public function creditorSale()
    {
        $last=Auth::user()->last_name;
        $first=Auth::user()->first_name;
        $name= $first.' '.$last ;
        $data['user_name'] = $name;
        // dd($data);
        $stocks = Stock::all();
        $data["stocks"] = $stocks;

        $customers = Customers::all();
        $data["customers"] = $customers;
        return view ('sales.creditor_sale', $data);
    }

    public function paymentHome()
    {
        $payments = Payment::all();
        $data["payments"] = $payments;

        
        return view ('payment.payments', $data)->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $input = $request->all();
        //  dd($input);
        $item = $input['item'];
        // dd($item);
        foreach($item as $key => $item)
        {
            $sale = new Sale;
            $sale->amount = $input['amount'][$key];
            $sale->item = $input['item'][$key];
            $sale->unit = $input['unit'][$key];
            $sale->sales_by = Auth::user()->id;

            // if(!empty($input['discount'][$key])) {
            //     $input['discount'][$key] =  $input['discount'][$key];
            // } else {
            //     $input['discount'][$key] = "";
            // }
            $sale->discount = $input['discount'][$key];
            $sale->order_id = $input['order_id'] = rand();
            $sale->save();
        }
        return view('invoice',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function pendingInvoice()
    {      
        $invoices = SalesDetails::where('status', 0 )->get();
        $data["invoices"] = $invoices;
        return view ('invoices.pending_invoice', $data)->with('i');      
    }

    public function paidInvoice()
    {      
        $invoices = SalesDetails::where('status', 1 )->get();
        $data["invoices"] = $invoices;
        return view ('invoices.settled_invoice', $data)->with('i');      
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Sale  $sale
     * @return \Illuminate\Http\Response
     */
    public function sales(Request $request)
    {
        $input = $request->all();
        $last=Auth::user()->last_name;
        $first=Auth::user()->first_name;
        $name= $first.' '.$last ;
       
        // $item = $input['item'];
        //  dd($input);
        // dd($order_id);
        try{
            $input = $request->all();
            $item = $input['item'];
            // dd($input);
            $salesBy = Auth::user()->id;
            // dd($salesBy);
            $customer = $input['customer_id'];
            $data['order_id'] = $order_id= $input['order_id'] = rand();
            // dd($input);
            foreach($item as $key => $item)
                {
                    $sale = new Sale;
                    $sale->amount = $input['total_amount'][$key];
                    $sale->item = $input['item'][$key];
                    $sale->unit = $input['quantity'][$key];
                    $sale->sales_by = Auth::user()->id;
                    $sale->discount = $input['discount'][$key];
                    $sale->order_id = $order_id;
                    $sale->customer_id = $customer;
                    $sale->save();
                    // dd($sale);
                    
                    $stock = Stock::where('id',  $sale->item)->first();
                    // dd($stock);
                    $stock_quantity = $stock->quantity - $sale->unit;
                    // dd($stock_quantity);
                    $stock->update(['quantity' => $stock_quantity]);
                    // dd($stock);
                }

                $data['details'] = $details = new SalesDetails;
                
                $details->amount = $input['all_sum'];
                $details->order_id = $order_id;
                $details->status = 0;
                $details->sales_by = Auth::user()->id;
                $details->name = $name;
                $details->customer_id = $customer;
                $details->save();

                $data['customer'] = $user = Customers::where('id', $customer)->firstorfail();
               // dd($details);
                $sales = Sale::where('order_id', $order_id)->get();
                $data["sales"] = $sales;

                $data["total_amount"] = $input['all_sum'];

                
            return view('invoice', $data);
        } 

        catch (\Exception $exception) {

            return redirect()->back()->withErrors(['exception' => $exception->getMessage()]);

        }
    }

    public function individualSales(Request $request)
    {
        $input = $request->all();
        $last=Auth::user()->last_name;
        $first=Auth::user()->first_name;
        $name= $first.' '.$last ;
       
        // $item = $input['item'];
        //  dd($input);
        // dd($order_id);
        try{
            $input = $request->all();
            $item = $input['item'];
            // dd($input);
            $salesBy = Auth::user()->id;
            // dd($salesBy);
            $data['buyer'] = $customer = $input['customer_id'];
            $data['order_id'] = $order_id= $input['order_id'] = rand();
            // dd($input);
            foreach($item as $key => $item)
                {
                    $sale = new Sale;
                    $sale->amount = $input['total_amount'][$key];
                    $sale->item = $input['item'][$key];
                    $sale->unit = $input['quantity'][$key];
                    $sale->sales_by = Auth::user()->id;
                    // $sale->discount = $input['discount'][$key];
                    $sale->order_id = $order_id;
                    $sale->customer_id = $customer;
                    // dd($sale);
                    $sale->save();
                    
                    $stock = Stock::where('id',  $sale->item)->first();
                    // dd($stock);
                    $stock_quantity = $stock->quantity - $sale->unit;
                    // dd($stock_quantity);
                    $stock->update(['quantity' => $stock_quantity]);
                    // dd($stock);
                }

                $data['details'] = $details = new SalesDetails;
                $details->amount = $input['all_sum'];
                $details->order_id = $order_id;
                $details->status = 0;
                $details->sales_by =  Auth::user()->id;
                $details->name = $name;
                $details->customer_id = $customer;
                // dd($details);
                $details->save();

               // dd($details);
                $sales = Sale::where('order_id', $order_id)->get();
                $data["sales"] = $sales;

                $data["total_amount"] = $input['all_sum'];

                
            return view('individual_invoice', $data);
        } 

        catch (\Exception $exception) {

            return redirect()->back()->withErrors(['exception' => $exception->getMessage()]);

        }
    }

    public function createCreditorSale(Request $request)
    {
        $input = $request->all();
        $last=Auth::user()->last_name;
        $first=Auth::user()->first_name;
        $name= $first.' '.$last ;
       
        // $item = $input['item'];
        //  dd($input);
        // dd($order_id);
        try{
            $input = $request->all();
            $item = $input['item'];
            // dd($input);
            $salesBy = Auth::user()->id;
            // dd($salesBy);
            $data['buyer'] = $customer = $input['customer_id'];
            $data['order_id'] = $order_id= $input['order_id'] = rand();
            // dd($input);
            foreach($item as $key => $item)
                {
                    $sale = new Sale;
                    $sale->amount = $input['total_amount'][$key];
                    $sale->item = $input['item'][$key];
                    $sale->unit = $input['quantity'][$key];
                    $sale->sales_by = Auth::user()->id;
                    // $sale->discount = $input['discount'][$key];
                    $sale->order_id = $order_id;
                    $sale->customer_id = $customer;
                    // dd($sale);
                    $sale->save();
                    
                    $stock = Stock::where('id',  $sale->item)->first();
                    // dd($stock);
                    $stock_quantity = $stock->quantity - $sale->unit;
                    // dd($stock_quantity);
                    $stock->update(['quantity' => $stock_quantity]);
                    // dd($stock);
                }

                $data['details'] = $details = new SalesDetails;
                $details->amount = $input['all_sum'];
                $details->order_id = $order_id;
                $details->status = 0;
                $details->is_credit = 1;
                $details->sales_by =  Auth::user()->id;
                $details->name = $name;
                $details->customer_id = $customer;
                // dd($details);
                $details->save();

               // dd($details);
                $sales = Sale::where('order_id', $order_id)->get();
                $data["sales"] = $sales;

                $data["total_amount"] = $input['all_sum'];

                
            return view('individual_invoice', $data);
        } 

        catch (\Exception $exception) {

            return redirect()->back()->withErrors(['exception' => $exception->getMessage()]);

        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Sale  $sale
     * @return \Illuminate\Http\Response
     */
    public function makePayment(Request $request)
    {
        $id = $request->id;
        // dd($id);
        $data['invoice'] = $invoice = SalesDetails::where('id', $request->id)->first();
        // dd($invoice);

        return view('invoice_payment',$data);
    }

    public function payment(Request $request)
    {
        $id = $request->id;
        try{
                $input = $request->all();
                $input['user_id'] = Auth::user()->id;
                $amount_paid =  $request->amount_paid;
                // dd($input);
                $payment = Payment::create($input);
                
                    
                $invoice =SalesDetails::where('order_id', $id)->first();
                $debitAmount = $invoice->amount;
                $outstanding = $debitAmount - $amount_paid ;
                $invoice->update(['status' => 1, 'amount' => $outstanding]);

                return api_request_response(
                    "ok",
                    "Data Update successful!",
                    success_status_code(),
                    $invoice
                );
            }
                // return redirect()->route('customer_ledger');
                catch (\Exception $exception) {
                    // DB::rollback();
             
                     return api_request_response(
                         "error",
                         $exception->getMessage(),
                         bad_response_status_code()
                     );
             
                  }
    }

    

    public function invoiceItems(Request $request)
    {
        // dd($request->id);
        $invoices= SalesDetails::where('id', $request->id)->first();
   
        $order_id=$invoices->order_id;
   
        $items = Sale::where('order_id', $order_id)->get();
        // dd($items);

    return response()->json($items);
    }

    public function dailySales(Request $request)
    {
        
        $start = Carbon::parse($request->start)->startOfDay(); 
        $end = Carbon::parse($request->end)->endOfDay();
        $id = Auth::user()->id;
        $data['sales'] = $sales=SalesDetails::whereBetween('created_at', [$start, $end])->where('sales_by', $id)->where('is_credit', null)->get();
        $data['sum'] = $sales->sum('amount');
        // dd($sum);
        return view ('sales.daily_sales', $data);
    }
    public function dailyIndividualSalesDetails(Request $request)
    {
        $order_id = $request->id;
        // dd($order_id);
        $start = Carbon::parse($request->start)->startOfDay(); 
        $end = Carbon::parse($request->end)->endOfDay();
        $id = Auth::user()->id;
        $data['sales'] = $sales=Sale::whereBetween('created_at', [$start, $end])->where('order_id', $order_id)->get();
        // dd($sales);
        return view ('sales.individual_daily_sales_details', $data);
    }
    public function dailyCustomerSales(Request $request)
    {
        $start = Carbon::parse($request->start)->startOfDay(); 
        $end = Carbon::parse($request->end)->endOfDay();
        $id = Auth::user()->id;
        $data['sales'] = $sales=Sale::whereBetween('created_at', [$start, $end])->where('sales_by', $id)->get();
        // dd($sales);
        return view ('sales.daily_customer_sales', $data);
    }

    public function dailyCreditorSale(Request $request)
    {
        $start = Carbon::parse($request->start)->startOfDay(); 
        $end = Carbon::parse($request->end)->endOfDay();
        $id = Auth::user()->id;
        $data['sales'] = $sales=SalesDetails::whereBetween('created_at', [$start, $end])->where('sales_by', $id)->where('is_credit', 1)->get();
        $data['sum'] = $sales->sum('amount');
        return view ('sales.daily_creditor_sales', $data);
    }
    
    public function invoices()
    {
        $sales = SalesDetails::all();
        $data['sales'] = $sales;

        return view('invoices.invoice_home',$data)->with('i');
    }

    public function searchAndFilter(Request $request) 
    {

      $mda=$request->get('mda');
    //   dd($mda);
         try {
              $sales= DB::table('sales')
              ->where('customer_id',  $mda)->where('amount', '>=',   1)->get();
            //   dd($sales);
                $data['total'] =  $sales->sum('amount');
              if(!count($sales))
              {
                throw new \Exception('There is no record for the selected account!');

                // $data['sales'] = $sales = collect([
                //   (object) [
                    
                //       "created_at" => "NIL",
                //       "order_id" => "NIL",
                //       "name" => "NIL",
                //       "amount" => "NIL",  
                //       "status" => "NIL",  
                //   ],
                 
                // ]);
              }
 
                              
             return api_request_response(
                   "ok",
                   "Data fetching successful!",
                   success_status_code(),
                   $sales
               );
         } catch(\Exception $exception) {
             return api_request_response(
               "error",
               $exception->getMessage(),
               bad_response_status_code()
           );
         }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Sale  $sale
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $last=Auth::user()->last_name;
        $first=Auth::user()->first_name;
        $name= $first.' '.$last ;
        $input = $request->all();
        // dd($input);
        $amount=$request->get('amount');
        $unit=$request->get('unit');
        $discount=$request->get('discount');
        $item=$request->get('item');
        $sales_by= Auth::user()->id;
        $order_id= rand();
        for($i = 0; $i < count($request->get('item')); $i++)
        {
            $Record=new Sale;
            $Record->amount =    $amount[$i];
            $Record->unit =           $unit[$i];
            $Record->discount =            $discount[$i];
            $Record->item =           $item[$i];
            $Record->order_by =           $order_id;
            $Record->sales_by =           $sales_by;
            $Record->save();
        }
        return view('invoice',$data);
        
    }

    public function invoiceDetail(Request $request)
    {
        $id = $request->id;

        $invoices= SalesDetails::where('id', $request->id)->first();
   
        $order_id=$invoices->order_id;
   
        $data['items'] = Sale::where('order_id', $order_id)->get(); 
        // dd($data);
        return view ('invoice_details', $data)->with('i');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Sale  $sale
     * @return \Illuminate\Http\Response
     */
   
}
