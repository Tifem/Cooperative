<?php

namespace App\Http\Controllers;
use function App\Helpers\api_request_response;
use function App\Helpers\generate_random_password;
use function App\Helpers\generate_uuid;
use function App\Helpers\unauthorized_status_code;
use function App\Helpers\bad_response_status_code;
use function App\Helpers\success_status_code;
use App\Models\Account;
use App\Models\Receipt;
use Illuminate\Support\Facades\Session;
use App\Models\journal;
use App\Models\Cashbook;
use App\Models\Category;
use Carbon\Carbon;
use Datatables;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class journalController extends Controller
{
    public function index()
    {
        $category = Category::where('description', 'LIKE', "EXPENSES")->orWhere('description', 'LIKE', "INCOME")->pluck('id')->toArray();
        $group =  Category::whereIn('category_parent', $category)->pluck('id')->toArray();
        $data['accounts']  = Account::whereIn('category_id', $group)->get();
        $income = Category::where('description', 'LIKE', "ASSETS")->pluck('id')->toArray();  
        $incomeGroup =  Category::whereIn('category_parent', $income)->pluck('id')->toArray();
        $data['incomes']  = Account::whereIn('category_id', $incomeGroup)->get();   
        $data['transactions'] = Receipt::where('lodgement_status', 0)->get();
        // dd($data);
       return view('admin.journal.index', $data);
    }

    public function income(Request $request){
        if ($request->ajax()) { 
            $income = Category::where('description', 'LIKE', "ASSETS")->pluck('id')->toArray();  
            $incomeGroup =  Category::whereIn('category_parent', $income)->pluck('id')->toArray();
            $data['incomes'] =  $payments  = Account::whereIn('category_id', $incomeGroup)->where('created_at', '!=', null);
            // dd($income);
            return Datatables::of($payments)
            // dd($payments);
            ->addIndexColumn()
           
            ->make(true);
        }
    }

    public function save(Request $request)
    {
        // dd("here");
        // $input = $request->all();
        $getCode =  Account::where('id', $request->gl_code)->first();
        $code = $getCode->gl_code;
        $input = $request->except('_token');
        // $persie = intval(preg_replace('/[^\d.]/', '', $request->all_sum)) ;
        // dd($code);
        $input['particulars'] = $request->recepient_name;
        $input['teller_number'] = $request->teller_no;
        $item = $input['account_name'];
        $input['uuid'] = $order_id = rand();
        $input['voucher_number'] = $voucher =  rand();
        $input['lodgement_status'] =  0;
        $input['amount'] = intval(preg_replace('/[^\d.]/', '', $request->all_sum));
        $input['created_by'] =  Auth::user()->id;
        Session::put('voucherrr', $input['voucher_number']);

        try{           
             foreach($item as $key => $item)
                {
                    $journal = new journal;
                    // $account->account_name = $input['account_name'][$key];
                    $journal->gl_code = $input['account_name'][$key];
                    $journal->credit =  intval(preg_replace('/[^\d.]/', '', $request->amount[$key]));
                    $journal->uuid = $input['uuid'];
                    $journal->save();
                }

                $newJournal =  $account = new journal;
                // $newJournal->account_name = $input['account_name'];
                $newJournal->gl_code = $request->gl_code;
                $newJournal->debit = $input['amount'];
                $newJournal->uuid = $input['uuid'];
                $newJournal->save();

                $details = Receipt::create($input);
                $id = $details->uuid;

                return api_request_response(
                    "ok",
                    "Data Update successful!",
                    success_status_code(),
                    $details
                );
        }

        catch (\Exception $exception) {
            return api_request_response(
                "error",
                $exception->getMessage(),
                bad_response_status_code()
            );
            // return redirect()->back()->withErrors(['exception' => $exception->getMessage()]);
        }
    }

    public function lodge(Request $request)
    {
            $data['items'] = Category::whereNull('category_id')->get();

            try{
                $income = Category::where('description', 'LIKE', "INCOME")->pluck('id')->toArray();  
                $incomeGroup =  Category::whereIn('category_parent', $income)->pluck('id')->toArray();
                $data['accounts']  = Account::whereIn('category_id', $incomeGroup)->get(); 
                // dd($income);  
                // $data['accounts'] = Account::whereIn('gl_code', ["12","13","14","15","16","17"])->get();
                $input = $request->all();
                $uuid = $input['uuid'];
                $data["transactions"] = $stake = Receipt::whereIn('uuid', $uuid)->get();
                $data["sum"] = $stake->sum('amount');

                return view('admin.journal.lodge', $data);

            }catch (\Exception $exception) {
               
                return redirect()->back()->withErrors(['exception' => $exception->getMessage()]);
            }

    }

    public function bankLodge(Request $request)
    {
        try{
            $input = $request->all();
            // dd($input);
            $uuid = $input['uuid'];
            $code = Account::where('id',$request->bank_lodge)->first();
            $codevalue = $code->gl_code;
            // dd($uuid);
            foreach ($uuid as $key => $uuid) { 
                // $checkUp[] = Receipt::where('uuid', $uuid)->first(); 
                $value = Receipt::where('uuid', $uuid)->first(); 
                $value->update(['lodgement_status' => 1, 'bank_lodged' => $request->bank_lodge, 'date_lodged' => Carbon::now()]);
                
                $details = Journal::where('uuid', $uuid)->orderBy('id', 'desc')->first();
                $glcode = $details->gl_code;

                $newJournal = new Journal;
                $newJournal->gl_code = $request->bank_lodge;
                $newJournal->credit = $details->debit;
                $newJournal->uuid = $details->uuid;
                $newJournal->save();

                $cashbook = new Cashbook;
                $cashbook->transaction_date = Carbon::now();
                $cashbook->particular = $value->particulars;
                $cashbook->details = $value->description;
                $cashbook->bank = $value->amount;
                $cashbook->gl_code = $request->bank_lodge;
                $cashbook->save();
                // dd($newJournal);
            }

            return api_request_response(
                "ok",
                "Data Update successful!",
                success_status_code(),
                $value
            );
        }

        catch (\Exception $exception) {

            return redirect()->back()->withErrors(['exception' => $exception->getMessage()]);
        }
    }
}
