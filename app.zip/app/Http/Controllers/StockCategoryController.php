<?php

namespace App\Http\Controllers;
use function App\Helpers\api_request_response;
use function App\Helpers\generate_random_password;
use function App\Helpers\generate_uuid;
use function App\Helpers\unauthorized_status_code;
use function App\Helpers\bad_response_status_code;
use function App\Helpers\success_status_code;

use App\StockCategory;
use Illuminate\Http\Request;

class StockCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $stockCategories = StockCategory::all();
        $data["stockCategories"] = $stockCategories;
        return view ('stocks.stock_category', $data)->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $input = $request->all();
   
           try{
    
                $stockCategory = StockCategory::create($input);
    
                $success['stockCategory'] = $stockCategory;
    
                return api_request_response(
                    "ok",
                    "Data Update successful!",
                    success_status_code(),
                    $stockCategory
                );
           } 
    
            catch (\Exception $exception) {
           // DB::rollback();
    
            return api_request_response(
                "error",
                $exception->getMessage(),
                bad_response_status_code()
            );
    
         }


    }

    public function edit(Request $request)
    {
         //  dd($request->all());
         $stockCategory =  StockCategory::where('id',   $request->id)->first();//Beneficiaries::all();
        //  $price['data'] = $stock -> unit_price;
        //  dd($stock);
         return response()->json($stockCategory);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {

        // dd("here");
         try{
                $input = $request->all();
               $id =$request->id;
 
              $stockCategory = StockCategory::where('id',$id)->firstOrFail();
              
              $stockCategory=  $stockCategory->update($input);
 
               return api_request_response(
                   "ok",
                   "Data Update successful!",
                   success_status_code(),
                   $stockCategory
               );
         }
           catch (\Exception $exception) {
           return api_request_response(
               "error",
               $exception->getMessage(),
               bad_response_status_code()
           );
 
       }
 
 
    }

    public function delete(Request $request)
    {
        $id=$request->id;


        $stockCategory = StockCategory::find($id);
        $stockCategory->delete(); 

        return redirect()->back()->with('deleted', 'Delete Success!');
    }
    /**
     * Display the specified resource.
     *
     * @param  \App\StockCategory  $stockCategory
     * @return \Illuminate\Http\Response
     */
    public function show(StockCategory $stockCategory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\StockCategory  $stockCategory
     * @return \Illuminate\Http\Response
     */
    public function eit(StockCategory $stockCategory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\StockCategory  $stockCategory
     * @return \Illuminate\Http\Response
     */
    public function pdate(Request $request, StockCategory $stockCategory)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\StockCategory  $stockCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(StockCategory $stockCategory)
    {
        //
    }
}
