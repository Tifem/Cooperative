<?php

namespace App\Http\Controllers;
use function App\Helpers\api_request_response;
use function App\Helpers\generate_random_password;
use function App\Helpers\generate_uuid;
use function App\Helpers\unauthorized_status_code;
use function App\Helpers\bad_response_status_code;
use function App\Helpers\success_status_code;
use App\SecondStock;
use App\SalesDetails;
use Carbon\Carbon;
use App\Sale;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class SecondStockController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $stocks = SecondStock::all();
        $data["stocks"] = $stocks;
        return view ('stocks.second_stock', $data)->with('i');
    }

    public function customer()
    {
        $stocks = SecondStock::all();
        $data["stocks"] = $stocks;
        return view ('customer_sales_home', $data);
    }

    public function customerDiscountSales(Request $request)
    {
        $input = $request->all();
        $last=Auth::user()->last_name;
        $first=Auth::user()->first_name;
        $name= $first.' '.$last ;

        try{
            $input = $request->all();
            $item = $input['item'];
            $salesBy = Auth::user()->id;
            $data['buyer'] = $customer = $input['customer_id'];
            $data['order_id'] = $order_id= $input['order_id'] = rand();
            foreach($item as $key => $item)
                {
                    $sale = new Sale;
                    $sale->amount = $input['total_amount'][$key];
                    $sale->item = $input['item'][$key];
                    $sale->unit = $input['quantity'][$key];
                    $sale->sales_by = Auth::user()->id;
                    $sale->discount = $input['discount'][$key];
                    $sale->order_id = $order_id;
                    $sale->customer_id = $customer;
                    $sale->save();
                    
                    $stock = SecondStock::where('id',  $sale->item)->first();
                    // dd($stock);
                    $stock_quantity = $stock->quantity - $sale->unit;
                    // dd($stock_quantity);
                    $stock->update(['quantity' => $stock_quantity]);
                    // dd($stock);
                }

                $data['details'] = $details = new SalesDetails;
                
                $details->amount = $input['all_sum'];
                $details->order_id = $order_id;
                $details->status = 0;
                $details->sales_by = Auth::user()->id;
                $details->name = $name;
                $details->customer_id = $customer;
                $details->save();

                $sales = Sale::where('order_id', $order_id)->get();
                $data["sales"] = $sales;

                $data["total_amount"] = $input['all_sum'];

            return view('individual_invoice', $data);
        } 

        catch (\Exception $exception) {

            return redirect()->back()->withErrors(['exception' => $exception->getMessage()]);

        }
    }

    public function individualSales(Request $request)
    {
        $input = $request->all();
        $last=Auth::user()->last_name;
        $first=Auth::user()->first_name;
        $name= $first.' '.$last ;
       
        // $item = $input['item'];
        //  dd($input);
        // dd($order_id);
        try{
            $input = $request->all();
            $item = $input['item'];
            // dd($input);
            $salesBy = Auth::user()->id;
            // dd($salesBy);
            $data['buyer'] = $customer = $input['customer_id'];
            $data['order_id'] = $order_id= $input['order_id'] = rand();
            // dd($input);
            foreach($item as $key => $item)
                {
                    $sale = new Sale;
                    $sale->amount = $input['total_amount'][$key];
                    $sale->item = $input['item'][$key];
                    $sale->unit = $input['quantity'][$key];
                    $sale->sales_by = Auth::user()->id;
                    // $sale->discount = $input['discount'][$key];
                    $sale->order_id = $order_id;
                    $sale->customer_id = $customer;
                    $sale->save();
                    // dd($sale);
                    
                    $stock = SecondStock::where('id',  $sale->item)->first();
                    $stock_quantity = $stock->quantity - $sale->unit;
                    // dd($stock);
                    // dd($stock_quantity);
                    $stock->update(['quantity' => $stock_quantity]);
                    // dd($stock);
                }

                $data['details'] = $details = new SalesDetails;
                $details->amount = $input['all_sum'];
                $details->order_id = $order_id;
                $details->status = 0;
                $details->sales_by =  Auth::user()->id;
                $details->name = $name;
                $details->customer_id = $customer;
                // dd($details);
                $details->save();

               // dd($details);
                $sales = Sale::where('order_id', $order_id)->get();
                $data["sales"] = $sales;

                $data["total_amount"] = $input['all_sum'];

                
            return view('individual_invoice', $data);
        } 

        catch (\Exception $exception) {

            return redirect()->back()->withErrors(['exception' => $exception->getMessage()]);

        }
    }
    public function create(Request $request)
    {
        $input = $request->all();
   
        try{
 
             $stocks = SecondStock::create($input);
 
             $success['stocks'] = $stocks;
 
             return api_request_response(
                 "ok",
                 "Data Update successful!",
                 success_status_code(),
                 $stocks
             );
        } 
 
         catch (\Exception $exception) {
        // DB::rollback();
 
         return api_request_response(
             "error",
             $exception->getMessage(),
             bad_response_status_code()
         );
 
      }
    }


    public function individual()
    {
        $stocks = SecondStock::all();
        $data["stocks"] = $stocks;

        return view ('sales.abk_individual', $data);
    }

    public function stockPrice(Request $request)
    {
          $stock  =  SecondStock::where('id',   $request->id)->first();

          return response()->json($stock);
    }

    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\SecondStock  $secondStock
     * @return \Illuminate\Http\Response
     */
    public function show(SecondStock $secondStock)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\SecondStock  $secondStock
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
          //  dd($request->all());
          $stocks=  SecondStock::where('id',   $request->id)->first();//Beneficiaries::all();
          //  $price['data'] = $stock -> unit_price;
          //  dd($stock);
           return response()->json($stocks);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\SecondStock  $secondStock
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        try{
            $input = $request->all();
           $id =$request->id;

          $stocks = SecondStock::where('id',$id)->firstOrFail();
          
          $stocks=  $stocks->update($input);

           return api_request_response(
               "ok",
               "Data Update successful!",
               success_status_code(),
               $stocks
           );
     }
       catch (\Exception $exception) {
       return api_request_response(
           "error",
           $exception->getMessage(),
           bad_response_status_code()
       );

   }


}
    
    

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\SecondStock  $secondStock
     * @return \Illuminate\Http\Response
     */
    public function delete(Request $request)
    {
        $id=$request->id;


        $stocks = SecondStock::find($id);
        $stocks->delete(); 

        return redirect()->back()->with('deleted', 'Delete Success!');
    }
}
