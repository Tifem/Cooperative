<?php

namespace App\Http\Controllers;
use function App\Helpers\api_request_response;
use function App\Helpers\generate_random_password;
use function App\Helpers\generate_uuid;
use function App\Helpers\unauthorized_status_code;
use function App\Helpers\bad_response_status_code;
use function App\Helpers\success_status_code;
use App\StockCategory;
use App\StockDelivery;
use App\Stock_received;
use App\Stock;
use App\Customers;
use App\Location;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LocationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $locations = Location::all();
        $data["locations"] = $locations;
        return view ('location', $data)->with('i');
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $input = $request->all();


           try{

                $location = Location::create($input);

                $success['location'] = $location;

                return api_request_response(
                    "ok",
                    "Data Update successful!",
                    success_status_code(),
                    $location
                );
           }

            catch (\Exception $exception) {
           // DB::rollback();

            return api_request_response(
                "error",
                $exception->getMessage(),
                bad_response_status_code()
            );

         }


    }

    public function delete(Request $request)
    {
        $id=$request->id;


        $location = Location::find($id);
        $location->delete();

        return redirect()->back()->with('deleted', 'Delete Success!');
    }

    public function edit(Request $request)
    {
         //  dd($request->all());
         $location =  Location::where('id',   $request->id)->first();//Beneficiaries::all();
        //  $price['data'] = $stock -> unit_price;
        //  dd($stock);
         return response()->json($location);
    }

    public function update(Request $request)
    {

        // dd("here");
         try{
                $input = $request->all();
               $id =$request->id;

              $location = Location::where('id',$id)->firstOrFail();

              $location=  $location->update($input);

               return api_request_response(
                   "ok",
                   "Data Update successful!",
                   success_status_code(),
                   $location
               );
         }
           catch (\Exception $exception) {
           return api_request_response(
               "error",
               $exception->getMessage(),
               bad_response_status_code()
           );

       }


    }

    public function stockDelivery(Request $request)
    {
        $input = $request->all();
        // dd($input);

        try{
            $input = $request->all();
            $item = $input['item'];
            // dd($input);
            $user_id = Auth::user()->id;
            // dd($salesBy);
            $supplier_id = $input['customer_id'];
            $data['order_id'] = $order_id= $input['order_id'] = rand();
            $amount = 2000;
            foreach($item as $key => $item)
                {
                    $stock_item = new StockDelivery;
                    $stock_item->total_amount = $amount;
                    $stock_item->item = $input['item'][$key];
                    $stock_item->quantity = $input['quantity'][$key];
                    // dd($stock_item);
                    $stock_item->purchase_order = $order_id;
                    $stock_item->supplier = $supplier_id;
                    $stock_item->save();
                    // dd($stock_item);
                    $stock = Stock::where('id',  $stock_item->item)->first();
                    $stock_quantity = $stock->quantity + $input['quantity'][$key];
                    // dd($stock_quantity);
                    $stock->update(['quantity' => $stock_quantity]);
                }

                $data['details'] = $details = new Stock_received;
                $details->total_quantity = $input['all_sum'];
                $details->purchase_order = $order_id;
                $details->user_id = Auth::user()->id;
                $details->supplier_id = $supplier_id;
                $details->save();

                return api_request_response(
                    "ok",
                    "Data Update successful!",
                    success_status_code(),
                    $details
                );

        }

        catch (\Exception $exception) {

            return redirect()->back()->withErrors(['exception' => $exception->getMessage()]);

        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Location  $location
     * @return \Illuminate\Http\Response
     */
    public function show(Location $location)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Location  $location
     * @return \Illuminate\Http\Response
     */
    public function edt(Location $location)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Location  $location
     * @return \Illuminate\Http\Response
     */
    public function updae(Request $request, Location $location)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Location  $location
     * @return \Illuminate\Http\Response
     */
    public function destroy(Location $location)
    {
        //
    }
}
