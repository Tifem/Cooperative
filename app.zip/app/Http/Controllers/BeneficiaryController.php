<?php

namespace App\Http\Controllers;


use function App\Helpers\api_request_response;
use function App\Helpers\generate_random_password;
use function App\Helpers\generate_uuid;
use function App\Helpers\unauthorized_status_code;
use function App\Helpers\success_status_code;
use function App\Helpers\bad_response_status_code;

use App\Mail\SendRegistrationDetails;
use App\Mail\SuperAdminAssignment;
use App\Models\User;
use App\Models\Beneficiary;
use App\Models\BeneficiaryAccount;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\Request;

class BeneficiaryController extends Controller
{
    public function index()
    {
        // return beneficiary list
        $data['beneficiaries'] = Beneficiary::all();

        return view('admin.beneficiary.index', $data);
    }


    public function add_beneficiary()
    {
        return view('admin.beneficiary.create');
    }


    public function edit_beneficiary(Request $request)
    {

        $data['beneficiary'] = Beneficiary::where('id', $request->id)->first();
        $data['beneficaryAccounts'] = BeneficiaryAccount::where('beneficiary_id', $request->id)->get();

        return view('admin.beneficiary.edit', $data);
    }

    public function update_beneficiary(Request $request)
    {
        $input = $request->all();
        // dd($input);

        //check duplicate beneficiary account
        // $thisBeneficiary = Beneficiary::where('email', $request->email)->first();
        // if ($thisBeneficiary) {
        //     return redirect()->back()->withErrors('There is a beneficiary with this email');
        // }
        //save to benefeciary table

        $beneficiary = Beneficiary::where('id',$request->id)->first();
        $beneficiary->name = $request->name;
        $beneficiary->email = $request->email;
        $beneficiary->phone_number = $request->phone_number;
        $beneficiary->address = $request->address;
        $saveBeneficiary = $beneficiary->save();

        //save to beneficiary account table
        $bankName = $request->bank_name;
        foreach ($bankName as $key => $name) {
            $beneficiaryAcc = BeneficiaryAccount::where('id',$beneficiary->id)->first();
            $beneficiaryAcc->beneficiary_id = $beneficiary->id;
            $beneficiaryAcc->bank_name = $name;
            $beneficiaryAcc->bank_account = $request->account_number[$key];
            $beneficiaryAcc->account_name = $request->account_name[$key];
            $savebeneficiaryAcc = $beneficiaryAcc->save();
        }



        return redirect()->back()->with('message', 'Beneficiary updated successfully');
    }
    public function create_beneficiary(Request $request)
    {
        $input = $request->all();
        // dd($input);

        //check duplicate beneficiary account
        $thisBeneficiary = Beneficiary::where('email', $request->email)->first();
        if ($thisBeneficiary) {
            return redirect()->back()->withErrors('There is a beneficiary with this email');
        }
        //save to benefeciary table

        $beneficiary = new Beneficiary();
        $beneficiary->name = $request->name;
        $beneficiary->email = $request->email;
        $beneficiary->phone_number = $request->phone_number;
        $beneficiary->address = $request->address;
        $saveBeneficiary = $beneficiary->save();

        //save to beneficiary account table
        $bankName = $request->bank_name;
        foreach ($bankName as $key => $name) {
            $beneficiaryAcc = new BeneficiaryAccount();
            $beneficiaryAcc->beneficiary_id = $beneficiary->id;
            $beneficiaryAcc->bank_name = $name;
            $beneficiaryAcc->bank_account = $request->account_number[$key];
            $beneficiaryAcc->account_name = $request->account_name[$key];
            $savebeneficiaryAcc = $beneficiaryAcc->save();
        }



        return redirect()->back()->with('message', 'Beneficiary added successfully');
    }


    public function getBeneficiaryAccount(Request $request)
    {
        $id = $request->id;
        $data['data'] = BeneficiaryAccount::where('beneficiary_id', $id)->get();
        return $data;
    }
}
