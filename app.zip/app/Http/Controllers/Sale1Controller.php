<?php

namespace App\Http\Controllers;
use function App\Helpers\api_request_response;
use function App\Helpers\generate_random_password;
use function App\Helpers\generate_uuid;
use function App\Helpers\unauthorized_status_code;
use function App\Helpers\bad_response_status_code;
use function App\Helpers\success_status_code;

use App\Sale;
use App\Stock;
use App\SalesDetails;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;




class SaleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $last=Auth::user()->last_name;
        $first=Auth::user()->first_name;
        $name= $first.' '.$last ;
        $data['user_name'] = $name;
        // dd($data);
        $stocks = Stock::all();
        $data["stocks"] = $stocks;
        return view ('sales3', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $input = $request->all();
        // dd($input);
        $item = $input['item'];
        // dd($item);
        foreach($item as $key => $item)
        {
            $sale = new Sale;
            $sale->amount = $input['amount'][$key];
            $sale->item = $input['item'][$key];
            $sale->unit = $input['unit'][$key];
            $sale->sales_by = Auth::user()->id;
            $sale->discount = $input['discount'][$key];
            $sale->order_id = $input['order_id'] = rand();
            $sale->save();
        }
        return view('invoice',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function pendingInvoice()
    {      
        $invoices = SalesDetails::where('status', 0 )->get();
        $data["invoices"] = $invoices;
        return view ('pending_invoice', $data)->with('i');      
    }

    public function paidInvoice()
    {      
        $invoices = SalesDetails::where('status', 1 )->get();
        $data["invoices"] = $invoices;
        return view ('settled_invoice', $data)->with('i');      
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Sale  $sale
     * @return \Illuminate\Http\Response
     */
    public function sales(Request $request)
    {
        $input = $request->all();
        $last=Auth::user()->last_name;
        $first=Auth::user()->first_name;
        $name= $first.' '.$last ;
        // $last =  $request->all();
        // dd(last);
        try{
            $last =  $request->all();
            // dd($last);
            $item = $input['item'];

            $order_id= $input['order_id'] = rand();

            foreach($item as $key => $item)
                {
                    $sale = new Sale;
                    $sale->amount = $input['amount'][$key];
                    $sale->item = $input['item'][$key];
                    $sale->unit = $input['unit'][$key];
                    $sale->sales_by = Auth::user()->id;
                    $sale->discount = $input['discount'][$key];
                    $sale->order_id = $order_id;
                    $sale->save();

                    $stock = Stock::where('id',  $sale->item)->first();
                    // dd($stock);
                    $stock_quantity = $stock->quantity - $sale->unit;
                    // dd($stock_quantity);
                    $stock->update(['quantity'=>$stock_quantity]);
                }

                $details = new SalesDetails;
                $details->name = $input['name'];
                $details->amount = $input['all_sum'];
                $details->order_id = $order_id;
                $details->status = 0;
                $details->save();

                $sales = Sale::where('order_id', $order_id)->get();
                $data["sales"] = $sales;

                $data["total_amount"] = $input['all_sum'];

               // dd("here");

                
            return view('invoice', $data);
        } 

        catch (\Exception $exception) {

            return redirect()->back()->withErrors(['exception' => $exception->getMessage()]);

        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Sale  $sale
     * @return \Illuminate\Http\Response
     */
    public function makePayment(Request $request)
    {
        $id = $request->id;
        // dd($id);
        $data['invoice'] = $invoice = SalesDetails::where('id', $request->id)->first();
        // dd($invoice);

        return view('invoice_payment',$data);
    }

    public function payment(Request $request)
    {
        $id = $request->id;
        // dd($id);

        $invoice =SalesDetails::where('id', $id)->first();

      //  dd($request->all());

        $invoice->update(['status' => 1,]);

        return redirect()->back();
    }

    public function invoiceItems(Request $request)
    {
        // dd($request->id);
        $invoices= SalesDetails::where('id', $request->id)->first();
   
        $order_id=$invoices->order_id;
   
        $items = Sale::where('order_id', $order_id)->get();
        // dd($items);

    return response()->json($items);
    }
    
    public function invoices()
    {
        $sales = SalesDetails::all();
        $data['sales'] = $sales;

        return view('invoice_home',$data)->with('i');
    }

    public function searchAndFilter(Request $request) 
    {

      $mda=$request->get('mda');
      
         try {
              $sales= DB::table('sales')
              ->where('order_id',  $mda)->get();

              if(!count($sales))
              {
                $sales = collect([
                  (object) [
                    
                      "created_at" => "NIL",
                      "order_id" => "NIL",
                      "name" => "NIL",
                      "amount" => "NIL",  
                      "status" => "NIL",  
                  ],
                 
                ]);
              }
 
                              
             return api_request_response(
                   "ok",
                   "Data fetching successful!",
                   success_status_code(),
                   $sales
               );
         } catch(\Exception $exception) {
             return api_request_response(
               "error",
               $exception->getMessage(),
               bad_response_status_code()
           );
         }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Sale  $sale
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $last=Auth::user()->last_name;
        $first=Auth::user()->first_name;
        $name= $first.' '.$last ;
        $input = $request->all();
        // dd($input);
        $amount=$request->get('amount');
        $unit=$request->get('unit');
        $discount=$request->get('discount');
        $item=$request->get('item');
        $sales_by= Auth::user()->id;
        $order_id= rand();
        for($i = 0; $i < count($request->get('item')); $i++)
        {
            $Record=new Sale;
            $Record->amount =    $amount[$i];
            $Record->unit =           $unit[$i];
            $Record->discount =            $discount[$i];
            $Record->item =           $item[$i];
            $Record->order_by =           $order_id;
            $Record->sales_by =           $sales_by;
            $Record->save();
        }
        return view('invoice',$data);
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Sale  $sale
     * @return \Illuminate\Http\Response
     */
   
}
