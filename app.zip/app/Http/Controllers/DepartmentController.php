<?php

namespace App\Http\Controllers;

use App\Models\Department;
use Illuminate\Http\Request;

class DepartmentController extends Controller
{

    public function index()
    {
        $data['departments'] = Department::all();
        return view('admin.department.index', $data);
    }

    public function edit_department(Request $request)
    {
        $data= Department::where('id', $request->id)->first();

        return response()->json($data);
    }

    public function store(Request $request)
    {
        $input = $request->all();

        //validate record
        if(Department::where('name', $request->name)->first()){
            return redirect()->back()->withErrors('Department already added');
        }
        $saveDepartment = Department::create($input);
        return redirect()->back()->with('message','Department added successfully');
    }
    public function update(Request $request)
    {
        $id = $request->id;
        $updateDepartment = Department::where('id', $id)->update(['name'=>$request->name]);
        return redirect()->back()->with('message','Department updated successfully');
    }

    public function delete(Request $request)
    {
        $id = $request->id;
        $updateDepartment = Department::where('id', $id)->delete();
        return redirect()->back()->with('message','Department deleted successfully');
    }
    //
}
