<?php

namespace App\Http\Controllers;

use App\Models\Tax;
use App\Models\TaxDeduction;
use Illuminate\Http\Request;

class TaxController extends Controller
{
    public function index()
    {
        $data['taxes'] = Tax::all();

        return view('admin.payment.tax.index', $data);
    }

    public function StoreTax(Request $request)
    {
        $this->validate($request, [
            'account_number' => 'max:10|min:10'
        ]);
        try {
            $input = $request->all();
            $saveInput = Tax::create($input);
            return redirect()->back()->with('message', 'Tax has been created successfuly');
        } catch (\Exception $exception) {
            // DB::rollback();
            return redirect()->back()->withErrors($exception->getMessage());
        }
    }


    public function UpdateTax(Request $request)
    {
        $this->validate($request, [
            'account_number' => 'max:10|min:10'
        ]);
        try{
       $id = $request->id;
       $input = $request->all();
       $tax = Tax::find($id);
       $tax->update($input);
       return redirect()->back()->with('message', 'Tax has been updated successfuly');
    } catch (\Exception $exception) {
        // DB::rollback();
        return redirect()->back()->withErrors($exception->getMessage());
    }
    }

    public function gettaxInfo(Request $request)
    {
        $data['tax'] =$tax= Tax::where('id', $request->id)->first();


        return response()->json($data);
    }

    public function delete(Request $request)
    {
        $id = $request->id;
        Tax::find($id)->delete();

        return redirect()->back()
        ->with('success', 'Record deleted successfully');
    }
}
