<?php

namespace App\Http\Controllers;


use function App\Helpers\api_request_response;
use function App\Helpers\generate_random_password;
use function App\Helpers\generate_uuid;
use function App\Helpers\unauthorized_status_code;
use function App\Helpers\success_status_code;
use function App\Helpers\bad_response_status_code;

use App\Mail\SendRegistrationDetails;
use App\Mail\SuperAdminAssignment;
use App\Models\User;
use App\Models\Beneficiary;
use App\Models\BeneficiaryAccount;
use App\Models\PaymentVoucher;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\Request;

class PaymentController extends Controller
{

    public function vouchers()
    {
        $data['vouchers'] = PaymentVoucher::all();
        return view('admin.payment.vouchers', $data);
    }


    public function prepare_voucher()
    {
        $data['vouchers'] = PaymentVoucher::all();
        $data['beneficiaries'] = Beneficiary::all();
        return view('admin.payment.prepare_voucher', $data);
    }

    public function save_voucher(Request $request)
    {
        $input = $request->all();
        // dd($input);
        $input['transaction_date'] = now();
        $input['prepared_by'] = Auth::user()->id;
        $input['approval_status'] = 0;
        $input['pvnumber'] = rand(1000, 9999);
        //  dd($input);
        if ($request->has('particulars')) {
            $input["particulars"] = $particularsName = time() . 'particulars'  . '.' . $request->particulars->extension();
            $request->particulars->move(public_path('particular'), $particularsName);
        }

        // dd($input);
        $saveVoucher = PaymentVoucher::create($input);

        return redirect()->back()->with('message', 'Voucher saved successfully');

        # code...
    }

    public function edit_voucher(Request $request)
    {
        $data['voucher'] = PaymentVoucher::where('id', $request->id)->first();
        $data['beneficiaries'] = Beneficiary::all();
        $data['beneficiaryAcc'] = BeneficiaryAccount::all();
      return  view('admin.payment.edit_voucher', $data);
    }

    public function print_voucher(Request $request)
    {
        $data['voucher'] = PaymentVoucher::where('id', $request->id)->first();

        return view('admin.payment.print_voucher', $data);
        # code...
    }


    //
}
