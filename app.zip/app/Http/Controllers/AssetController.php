<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Redirect;
use App\Models\Asset;
use App\Models\Asset_Disposal;
use App\Models\Asset_Supplier;
use App\Models\Assets_Classification;
use App\Models\AssetsType;
use App\Exports\AssetExport;
use App\Imports\AssetImport;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class AssetController extends Controller
{
    public function __construct()
    {
        // $this->middleware('permission:view-asset|view-user-asseys|edit-asset|update-asset', ['only' => ['index', 'store']]);
        // $this->middleware('permission:create-asset', ['only' => ['store']]);
        // $this->middleware('permission:edit-asset', ['only' => ['edit']]);
        // $this->middleware('permission:update-asset', ['only' => ['edit', 'update']]);
        // $this->middleware('permission:delete-asset', ['only' => ['delete']]);
    }

    public function asset_index()
    {
        $data['types'] = AssetsType::all();

        $data['classifications'] = Assets_Classification::all();
        $data['suppliers'] = Asset_Supplier::all();
        // when i disposed an asset it delete the asset from registration view and display in my disposal view
        $data['assets'] = Asset::whereNull('is_disposed')->get();
        // dd($data);
        return view('admin.assets.asset', $data);
    }

    public function create_asset()
    {
        $data['types'] = AssetsType::all();
        $data['classifications'] = Assets_Classification::all();
        $data['suppliers'] = Asset_Supplier::all();
        $data['assets'] = Asset::whereNull('is_disposed')->get();

        return view('admin.assets.asset_registration', $data);
    }

    public function store_asset(Request $request)
    {
        // dd($request->all());
        // if (Asset::where('asset_name', $request->asset_name)->first()) {
        //     return redirect()->back()->withErrors('This Asset has already been used, try to use another name');
        // }
        // if (Asset::where('serial_no', $request->serial_no)->first()) {
        //     return redirect()->back()->withErrors('This serial no has already been used, try to use another serial no');
        // }
        $input = $request->all();

        $user = Asset::create($input);

        // return redirect()->back()->with('success', 'Asset added successfully');
        return redirect()->route('assets_index')->with('message', 'Asset added successfully');
    }

    public function update_asset (Request $request)
    {
        $assets = Asset::find($request->id);
        if ($assets) {
            $this->validate($request, [
                'asset_name' => 'required',
                'type_id' => 'required',
                'description' => 'required',
                'serial_no' => 'required',
                'classification_id' => 'required',
                'dateofpurchase' => 'required',
                'amount_purchase' => 'required',
                'supplier_id' => 'required',
            ]);

            $input = $request->all();
            //dd($input);
            $assets->fill($input)->save();

            return redirect()->route('assets_index')->with('message', 'Asset updated successfully');
        }
    }

    public function edit_asset($id)
    {
        $data['types'] = AssetsType::all();
        $data['classifications'] = Assets_Classification::all();
        $data['suppliers'] = Asset_Supplier::all();
        $data['asset'] = Asset::find($id);

        return view('admin.assets.edit_asset', $data);
    }

    // public function getAssetInf(Request $request)
    // {
    //     $assetrss = Asset::where('id', $request->id)->first();

    //     return response()->json($assetrss);
    // }

    // public function discommunt(Request $request)
    // {
    //     $ct = Asset::count();

    //     return response()->json($assetrss);
    // }

    public function delete_asset(Request $request)
    {
        $id = $request->id;
        $user = Asset::find($id);
        // dd($user);
        $user->delete();

        return redirect()->back()->with('success', 'Asset deleted successfully');
    }

    // CLASSIFICATION

    public function classification_index()
    {
        $data['classifications'] = Assets_Classification::all();

        return view('admin.assets.asset_classification', $data);
    }

    public function store_classification(Request $request)
    {
        if (Assets_Classification::where('description', $request->description)->first()) {
            return redirect()->back()->withErrors('This description is already existing in your record, try to use another description');
        }
        $input = $request->all();
        // dd($input);
        $user = Assets_Classification::create($input);

        return redirect()->back()->with('message', 'Classification created successfully');
    }

    // public function store_classification()
    // {

    //     // dd($data);
    //     return view('admin.assetclassification',$data);
    // }

    public function update_classification (Request $request)
    {
        //  dd($request->all());
        $classify = Assets_Classification::find($request->id);
        if ($classify) {
            $this->validate($request, [
                'description' => 'required',
                'depreciation_method' => 'required',
                'depreciation_rate' => 'required'
            ]);

            $input = $request->all();
            // dd($supply);
            $classify->fill($input)->save();

            return redirect()->back()->with('message', 'Classification updated successfully');
        }
    }

    public function getAssetInfor(Request $request)
    {
        $classify = Assets_Classification::where('id', $request->id)->first();

        return response()->json($classify);
    }

    public function delete_classification(Request $request)
    {
        $id = $request->id;
        $user = Assets_Classification::find($id);
        // dd($user);
        $user->delete();

        return redirect()->back()->with('message', 'Classification deleted successfully');
    }

    // DISPOSAL
    public function disposal_index()
    {
        $data['disposals'] = Asset::where('is_disposed', 1)->get();
        $data['assetnames'] = Asset::all();
        // dd($data);
        return view('admin.assets.asset_disposal', $data);
    }

    public function create_disposal(Request $request)
    {
        $input = $request->all();
        // dd($input);
        $asset = $request->assets_id;

        $aseetData = Asset::where('id', $asset)->update([
            'is_disposed' => 1,
            'disposed_date' => $request->dateofdisposal,
            'amount_disposed' => $request->amount_disposed,
            'disposed_by' => Auth::user()->id,

        ]);

        return redirect()->back()->with('message', 'Asset disposed successfully');
    }

    // public function show_disposal()
    // {
    //     $data['assetnames'] = Asset::all();
    //     $data['disposaldate'] = Asset_Disposal::all();
    //     $data['amounts'] = Asset_Disposal::all();
    //     // dd($data);
    //     $data['disposal'] = Asset_Disposal::all();
    //     // dd($data);
    //     return view('admin.Disposal', $data);
    // }

    public function update_disposal(Request $request)
    {
        // dd($request->all());
        $disposal = Asset_Disposal::find($request->id);

        $this->validate($request, [
            'assets_id' => 'required',
            'dateofdisposal' => 'required',
            'amount_disposed' => 'required',
        ]);

        $input = $request->all();

        $disposal->fill($input)->save();

        return redirect()->back()->with('message', 'Asset disposed updated successfully');
    }

    public function delete_disposal(Request $request)
    {
        $id = $request->id;
        $user = Asset_Disposal::find($id);
        // dd($user);
        $user->delete();

        return redirect()->back()->with('message', 'Asset disposed deleted successfully');
    }

    // SUPPLIER

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function supplier_index()
    {
        $data['supplys'] = Asset_Supplier::all();

        return view('admin.assets.asset_supplier', $data);
    }

    public function create_supplier(Request $request)
    {
        if (Asset_Supplier::where('company_name', $request->company_name)->first()) {
            return redirect()->back()->withErrors('This company is already existing in your record, try to use another company name');
        }
        if (Asset_Supplier::where('company_email', $request->company_email)->first()) {
            return redirect()->back()->withErrors('This email is already existing in your record, try to use another email');
        }
        if (Asset_Supplier::where('company_phone', $request->company_phone)->first()) {
            return redirect()->back()->withErrors('This contact is already existing in your record, try to use another phone no');
        }

        $input = $request->all();
        // dd($input);
        $user = Asset_Supplier::create($input);

        return redirect()->back()->with('message', 'Supplier added successfully');
    }

    public function update_supplier(Request $request)
    {
        //  dd($request->all());
        $supply = Asset_Supplier::find($request->id);
        if ($supply) {
            $this->validate($request, [
                'company_name' => 'required',
                'company_address' => 'required',
                'company_email' => 'required',
                'company_phone' => 'required',
                'supplier_personalname' => 'required',
                'supplier_personalphone' => 'required',
                'supplier_personalemail' => 'required',
            ]);

            $input = $request->all();
            // dd($supply);
            $supply->fill($input)->save();

            return redirect()->back()->with('message', 'Supllier updated successfully');
        }
    }

    public function getAssetInfo(Request $request)
    {
        $supply = Asset_Supplier::where('id', $request->id)->first();

        return response()->json($supply);
    }

    public function delete_supplier(Request $request)
    {
        $id = $request->id;
        $user = Asset_Supplier::find($id);
        // dd($user);
        $user->delete();

        return redirect()->back()->with('message', 'Supplier deleted successfully');
    }

    public function download_asset_excel ($type)
    {
        // dd($type);
        return \Excel::download(new AssetExport, 'assets.' . $type);
    }

    public function upload_asset_excel (Request $request)
    {
        // dd($request->all());
        $type = $request->type_id;
        $classification = $request->classification_id;
        try{
        \Excel::import(new AssetImport($type, $classification), request()->file('asset_file')->store('temp'));

        return Redirect::back()->with( ['success' => 'Asset uploaded successfully!.'] );
    }
        catch (\Maatwebsite\Excel\Validators\ValidationException $e) {
            $failures = $e->failures();
            foreach ($failures as $failure) {
                $errormess = "";
                foreach($failure->errors() as $error)
                {
                    $errormess = $errormess.$error;
                }
                $errormessage[] = "There was an error on Row " . " ". $failure->row() .".". " " . $errormess ;
            }

            return redirect()->back()->withErrors($errormessage);
        }catch (\Exception $exception){
            $errorCode = $exception->errorInfo[1] ?? $exception;
            if(is_int($errorCode) ){
                return redirect()->back()->withErrors(['exception' => $exception->errorInfo[2]]);
            }else{
                // dd($exception);
                return redirect()->back()->withErrors(['exception' => $exception->getMessage()]);
            }
    }
    }

}
