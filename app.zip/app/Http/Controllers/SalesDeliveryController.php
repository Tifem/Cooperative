<?php

namespace App\Http\Controllers;

use App\SalesDelivery;
use Illuminate\Http\Request;

class SalesDeliveryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $input = $request->all();
        dd($input);
        if(!empty($request->input('discount'))) {
            $input['discount']= $request->input('discount');
        } else {
            $input['discount']= "";
        }
        
        $stockDelivery = StockDelivery::create($input);

        return view('billss',$data);

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\SalesDelivery  $salesDelivery
     * @return \Illuminate\Http\Response
     */
    public function show(SalesDelivery $salesDelivery)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\SalesDelivery  $salesDelivery
     * @return \Illuminate\Http\Response
     */
    public function edit(SalesDelivery $salesDelivery)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\SalesDelivery  $salesDelivery
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SalesDelivery $salesDelivery)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\SalesDelivery  $salesDelivery
     * @return \Illuminate\Http\Response
     */
    public function destroy(SalesDelivery $salesDelivery)
    {
        //
    }
}
