<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use function App\Helpers\api_request_response;
use function App\Helpers\generate_random_password;
use function App\Helpers\generate_uuid;
use function App\Helpers\unauthorized_status_code;
use function App\Helpers\bad_response_status_code;
use function App\Helpers\success_status_code;
use App\Models\Category;
use App\Models\Receipt;

class CategoryController extends Controller
{
   public function index() 
   {
       $data['categories'] = Category::whereNull('category_id')->get();
       $data['categoryId']= Category::pluck('category_id')->toArray();
       $revenue = Receipt::all();
       $data['revenue']=$revenue->sum('amount');
       $data['lodge'] = Receipt::where('lodgement_status', 1)->sum('amount');
       $data['outstanding'] = Receipt::where('lodgement_status', 0)->sum('amount');
       return view('admin.category.index', $data);
   }

   public function details(Request $request)
   {
       $data['categoryDetails']= Category::where('id', $request->id)->first();
       $data['categories']= Category::where('category_id', $request->id)->get();
       $data['categoryId']= Category::pluck('category_id')->toArray();
       $revenue = Receipt::all();
       $data['revenue']=$revenue->sum('amount');
       $data['lodge'] = Receipt::where('lodgement_status', 1)->sum('amount');
       $data['outstanding'] = Receipt::where('lodgement_status', 0)->sum('amount');
       return view( 'category.details',$data);
   }  

   public function getSubCategory(Request $request)
   {
    //    dd($request);
        $pp['data'] = $info = Category::where('category_id', $request->id)->get();
    //    $pp['data'] = Company::wherein('id', $bids)->get();
       //    dd($pp['data']);
       return json_encode($pp);
    //    dd($info);
   }

   public function create(Request $request)
    {
        $input = $request->all();
        $item = $input['description'];

            try{
                foreach($item as $key => $item)
                {
                    $account = new Category;
                    $account->description = $input['description'][$key];
                    $account->category_code = $input['category_code'][$key];
                    $account->code = $input['category_code'][$key];
                    $account->save();

                    $value = Category::whereNull('category_id')->get();
                    $count = $value->count();
                    $account->update(['category_parent' => $account->id, 'code' => $count. '' . "00" ]);
                }

                return api_request_response(
                    "ok",
                    "Data Update successful!",
                    success_status_code(),
                    $account
                );
            }

            catch (\Exception $exception) {
            // DB::rollback();

            return api_request_response(
                "error",
                $exception->getMessage(),
                bad_response_status_code()
            );

        }
    }

    public function addSubCategory(Request $request)
    {
        $input = $request->all();
        $item = $input['description'];
        $input['category_id'] = $request->id;
        // dd($input);
        $prev = Category::where('id', $request->id)->first();
        $code = $prev->code;
        $prev->update(['has_child' => 1]);
        // $child = Category::where('category_id', $request->id)->get();
        // $figure = $child->count();
        // dd($figure+1);
        // dd($code);
            try{
                foreach($item as $key => $item)
                {
                    $account = new Category;
                    $account->description = $input['description'][$key];
                    $account->category_code = $input['category_code'][$key];
                    $account->category_id =  $input['category_id'];
                    $account->save();

                    $child = Category::where('category_id', $request->id)->get();
                    $figure = $child->count();
                    $account->update(['category_parent' => $prev->category_parent, 'code' => $code. '' . "0". '' . $figure]);
                }
               
                return api_request_response(
                    "ok",
                    "Data Update successful!",
                    success_status_code(),
                    $prev
                );
            }

            catch (\Exception $exception) {
            // DB::rollback();

            return api_request_response(
                "error",
                $exception->getMessage(),
                bad_response_status_code()
            );

        }
    }

    public function deleteCategory(Request $request)
    {
        dd($request);
        $id=$request->id;
        $role = Category::find($id);
        dd($role);
        $roles = Category::where('category_id', $request->id)->get();
        if(!empty($roles))
        {
            $role->delete();
            return redirect()->back()->with('deleted', 'Delete Success!');
        }else{
            $update = Category::where('id',  $request->id )->first();
            $update->update(['has_child' => 0]);
            $role->delete();
            return redirect()->back()->with('deleted', 'Delete Success!');
        }

    }

    public function getCategoryId(Request $request)
    {
        $category =  Category::where('id',   $request->id)->first();
        return response()->json($category);
    }

}
