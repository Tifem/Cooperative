<?php

namespace App\Http\Controllers;
use function App\Helpers\api_request_response;
use function App\Helpers\generate_random_password;
use function App\Helpers\generate_uuid;
use function App\Helpers\unauthorized_status_code;
use function App\Helpers\bad_response_status_code;
use function App\Helpers\success_status_code;

use App\Customers;
use App\Sale;
use App\SalesDetails;
use Illuminate\Http\Request;

class CustomersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $customers = Customers::all();
        $data['customers'] = $customers;
        return view ('customers.customer', $data)->with('i');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function create_customer(Request $request)
    {
    $this->validate($request, [
        'name' => 'required',
        'address' => 'required',
        'office_address' => 'required',
        'phone' => 'required',
        'email' => 'required',
        ]);

        $input = $request->all();
        $Customer = Customers::create($input);

        return redirect()->back()->with('success', 'Customer created successfully');
    }

    public function create(Request $request)
    {
        // dd($request);
        $input = $request->all();

   
           try{
    
                $customer = Customers::create($input);
    
                $success['customer'] = $customer;
    
                return api_request_response(
                    "ok",
                    "Data Update successful!",
                    success_status_code(),
                    $customer
                );
           } 
    
            catch (\Exception $exception) {
           // DB::rollback();
    
            return api_request_response(
                "error",
                $exception->getMessage(),
                bad_response_status_code()
            );
    
         }

    }

    public function delete(Request $request)
    {
        $id=$request->id;


        $customer = Customers::find($id);
        $customer->delete(); 

        return redirect()->back()->with('deleted', 'Delete Success!');
    }

    public function getCustomerInfo(Request $request)
    {
        $customer = Customers::where('id', $request->id)->first();

        return response()->json($customer);
    }

    public function update_custom(Request $request)
    {
        $id= $request->id;
        $this->validate($request, [
        'name' => 'required',
        'address' => 'required',
        'office_address' => 'required',
        'phone' => 'required',
        'email' => 'required',
        ]);
        $input = $request->all();

        $customer = Customers::find($id);
        $customer->update($input);
        return redirect()->back()->with('success', 'Customer Details updated successfully');
    }

    public function edit(Request $request)
    {
         //  dd($request->all());
         $customer =  Customers::where('id',   $request->id)->first();//Beneficiaries::all();
        //  $price['data'] = $stock -> unit_price;
        //  dd($stock);
         return response()->json($customer);
    }

    public function customerLedger()
    {
        $data['customers'] = Customers::all();
        return view ('customers.customer_ledger', $data);
    }

    public function creditorsLedger()
    {
        $data['sales'] = SalesDetails::where('is_credit', 1)->where('amount', '>=',   1)->get();
        return view ('creditors_ledger', $data);
    }

    public function customerLedgerDetails(Request $request)
    {
        // dd($request->id);
        $data['sales'] = $sales =Sale::where('order_id', $request->id)->get();
// dd($data);
        return view ('customers.customer_ledger_details', $data);
    }

    public function ledgerPayment(Request $request)
    {
// dd($request->id);
        $data['invoice'] = $invoice = SalesDetails::where('order_id', $request->id)->first();
        // dd($invoice);

        return view('invoice_payment',$data);
    }

    public function update(Request $request)
    {

        // dd("here");
         try{
                $input = $request->all();
               $id =$request->id;
 
              $customer = Customers::where('id',$id)->firstOrFail();
              
              $customer=  $customer->update($input);
 
               return api_request_response(
                   "ok",
                   "Data Update successful!",
                   success_status_code(),
                   $customer
               );
         }
           catch (\Exception $exception) {
           return api_request_response(
               "error",
               $exception->getMessage(),
               bad_response_status_code()
           );
 
       }
 
 
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Customers  $customers
     * @return \Illuminate\Http\Response
     */
    public function show(Customers $customers)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Customers  $customers
     * @return \Illuminate\Http\Response
     */
    public function eit(Customers $customers)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Customers  $customers
     * @return \Illuminate\Http\Response
     */
    public function upate(Request $request, Customers $customers)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Customers  $customers
     * @return \Illuminate\Http\Response
     */
    public function destroy(Customers $customers)
    {
        //
    }
}
