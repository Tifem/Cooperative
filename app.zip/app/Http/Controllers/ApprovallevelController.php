<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ApprovalLevel;
use App\Models\User;
use Spatie\Permission\Models\Role;
use function App\Helpers\api_request_response;
use function App\Helpers\generate_random_password;
use function App\Helpers\generate_uuid;
use function App\Helpers\unauthorized_status_code;
use function App\Helpers\bad_response_status_code;
use function App\Helpers\success_status_code;
use Illuminate\Support\Arr;


class ApprovallevelController extends Controller
{

   public function __construct()
    {
        $this->middleware('auth');
        // $this->middleware('permission:role-list', ['only' => ['index']]);
     //   $this->middleware('role-create', ['only' => ['create']]);
    }

    public function index()
    {
        $data['modules'] = ApprovalLevel::all();
        $data['roles'] = Role::all();
        return view('approval_level.index', $data)->with('i');
    }

    public function viewdetails(Request $request)
    {
        $id = $request->id;
        $data['roles'] = Role::all();

        $data['approval_leveldetail'] = $approverlevel = ApprovalLevel::where('id', $request->id)->first();
        $approverlist = json_decode($approverlevel->list_of_approvers);
        foreach ($approverlist as $list) {
            $thisrole =   Role::where('id', $list)->first();
            $rolelistnme[] = $thisrole->name;
        }
        $data['rolenamelisttt'] = $rolelistnme;


        return view('approval_level.edit', $data)->with('i');
    }


    public function veiw_role_list(Request $request)
    {
        $role = $request->role;
        $roleID = Role::where('name', $role)->first();
        // dd($roleID);
        $data['users'] = User::role( $role)->get();
        $data['modules'] = ApprovalLevel::all();
        $data['roles'] = Role::all();
        return view('approval_level.user_list', $data)->with('i');
    }

    public function create(Request $request)
    {
        $input = $request->all();
        $input['module'] = $module = $request->module;
     // dd($request->all());
        // validate module
        $modulevalidation = ApprovalLevel::where('module', $module)->first();
        if (!$modulevalidation) {
            $input['list_of_approvers'] = json_encode(Arr::flatten($request->joints));
            // dd($input['list_of_approvers']);
            ApprovalLevel::create($input);
            return redirect()->back()->with('success', 'Approval Level created successfully');
        } else {
            return redirect()->back()->withErrors(['error' => 'Approval Level has been set for this module!']);
        }
        // dd($input);
    }
    public function update(Request $request)
    {
        // $input = $request->all();
        $module = $request->module;
        // validate module
        $thismodule = ApprovalLevel::where('module', $module)->first();

        $input['list_of_approvers'] = json_encode(Arr::flatten($request->joints));
        $thismodule->update($input);

        return redirect()->back()->with('success', 'Approval Level created successfully');

        // dd($input);
    }

    public  function delete(Request $request)
    {
        $id = $request->id;


        $approval = ApprovalLevel::find($id);
        $approval->delete(); //delete the client
        return redirect()->back()->with('deleted', 'Delete Success!');
        //Session::flash('message','Delete successfully.');
    }
}
