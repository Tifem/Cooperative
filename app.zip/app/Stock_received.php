<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Stock_received extends Model
{
    protected $table ='stock_received';
    protected $fillable = [
        'user_id',
        'supplier_id',
        'purchase_id',
        'total_quantity'

    ];
}
