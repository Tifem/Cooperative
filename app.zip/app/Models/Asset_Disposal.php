<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class assetsdisposal extends Model
{
    use HasFactory;
    protected $fillable = [
        'assets_id',
        'dateofdisposal',
        'amount_disposed',
    ];

    public function disp(){
        return $this->belongsTo('App\Models\assetsregistration', 'assets_id');  
    }
}
