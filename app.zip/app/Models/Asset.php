<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Asset extends Model
{
    use  HasFactory;
    protected $table = 'assets';
    protected $fillable = [
        'asset_name',
        'type_id',
        'description',
        'serial_no',
        'barcode',
        'classification_id',
        'dateofpurchase',
        'amount_purchase',
        'supplier_id',
        'is_disposed',
    ];

    public function astype()
    {
        return $this->belongsTo('App\Models\AssetsType', 'type_id');
    }

    public function descrip()
    {
        return $this->belongsTo('App\Models\Assets_Classification', 'description')->withDefault(['name'=> '']);
    }

    public function classify()
    {
        return $this->belongsTo('App\Models\Assets_Classification', 'description')->withDefault(['name'=> '']);
    }

    public function sup()
    {
        return $this->belongsTo('App\Models\Asset_Supplier', 'supplier_id')->withDefault(['name'=> '']);
    }
}
