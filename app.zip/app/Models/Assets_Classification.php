<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Assets_Classification extends Model
{
    use HasFactory;
    protected $table = 'assets_classifications';
    protected $fillable = [
        'description',
        'depreciation_method',
        'depreciation_rate',
    ];   
}
