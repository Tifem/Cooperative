<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;
class Account extends Model implements Auditable
{
    use HasFactory;
    use \OwenIt\Auditing\Auditable;
    protected $fillable = [
        'gl_name',
        'category_id',
        'balance',
        'direction',
        'created_by',
        'gl_code'
    ];

    public function category()
    {
        return $this->belongsTo('App\Models\Category', 'gl_code')->withDefault(['description'=>'Anonymous']);
    }
}
