<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;

class Manage_Account extends Model implements Auditable
{
    use \OwenIt\Auditing\Auditable;
    protected $table = 'manage_accounts';

    protected $fillable =[
    'recepient_name',
    'transaction_date',
    'description',
    'teller_no',
    'cash_account',
    'uu_id'
    ];
    use HasFactory;
}
