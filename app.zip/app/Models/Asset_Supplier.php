<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Asset_Supplier extends Model
{
    use HasFactory;
    protected $table = 'asset_suppliers';
    protected $fillable = [
        'company_name',
        'company_address',
        'company_email',
        'company_phone',
        'supplier_personalname',
        'supplier_personalphone',
        'supplier_personalemail',
    ];
}
