<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;

class Journal extends Model implements Auditable
{
    use HasFactory;
    use \OwenIt\Auditing\Auditable;
    protected $fillable = [
        'uuid',
        // 'account_name',
        'gl_code',
        // 'amount',
        // 'voucher_number',
        'debit',
        'credit'
    ];

    public function account()
    {
        return $this->belongsTo('App\Models\Account', 'gl_code')->withDefault(['name'=>'Anonymous']);
    }

    protected $casts = [
        'created_at' => 'datetime:Y-m-d H:i A','modified' => 'datetime:Y-m-d H:i A'
    ];
}
