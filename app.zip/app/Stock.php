<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Stock extends Model
{
    protected $table = "stocks";

    protected $fillable = [
        'name',
        'description',
        'unit_price',
        'classification',
        'category_id',
        're_order_level',
        'quantity',
        'unit_of_measurement',
        'stock_id',
    ];

    public function stock()
    {
        return $this->belongsTo('App\Stock','item')->withDefault(['name'=>'Anonymous']);
    }
}
